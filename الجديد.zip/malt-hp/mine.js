// MALT HP compatibility entry point.
// The website is served by server.js as requested.
// Run: node server.js
module.exports = { name: 'MALT HP', entry: 'server.js', port: 8080 };
