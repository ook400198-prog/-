(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const escape = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const labels = { article: 'مقال / بحث', course: 'دورة', lesson: 'درس', formulation: 'تركيبة غذائية', project: 'مشروع', service: 'خدمة / استشارة' };
  let sections = [];
  let items = [];
  let media = [];
  let sectionEditing = '';
  let savedSlug = '';

  async function api(url, options = {}) {
    const response = await fetch(url, { credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-MALT-Admin': '1', ...(options.headers || {}) }, ...options });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.message || `HTTP ${response.status}`);
    return result;
  }
  function notify(selector, message) { const node = $(selector); if (!node) return; node.textContent = message; }
  function flatten(nodes, depth = 0, output = []) { for (const node of nodes || []) { output.push({ ...node, depth }); flatten(node.children, depth + 1, output); } return output; }
  function renderTree() {
    const flat = flatten(sections);
    $('#cmsSectionParent').innerHTML = '<option value="">قسم رئيسي</option>' + flat.map((s) => `<option value="${escape(s.id)}" ${s.id === sectionEditing ? 'disabled' : ''}>${'— '.repeat(Math.min(s.depth, 10))}${escape(s.title)}</option>`).join('');
    $('#cmsItemSection').innerHTML = '<option value="">دون قسم</option>' + flat.map((s) => `<option value="${escape(s.id)}">${'— '.repeat(Math.min(s.depth, 10))}${escape(s.title)}</option>`).join('');
    const treeHtml = (nodes) => `<ul>${nodes.map((s) => `<li><div class="cms-tree-row"><button class="cms-tree-name" type="button" data-filter-section="${escape(s.id)}">${escape(s.title)}</button><small>${s.status === 'draft' ? 'مسودة' : 'منشور'}</small><button class="cms-tree-action" type="button" data-edit-section="${escape(s.id)}">تعديل</button><button class="cms-tree-action delete" type="button" data-delete-section="${escape(s.id)}">حذف</button></div>${s.children?.length ? treeHtml(s.children) : ''}</li>`).join('')}</ul>`;
    $('#cmsTree').innerHTML = sections.length ? treeHtml(sections) : '<p class="empty-state small">أنشئ أول قسم للبدء.</p>';
    $$('[data-filter-section]').forEach((b) => b.onclick = () => { $('#cmsItemSection').value = b.dataset.filterSection; loadItems(); });
    $$('[data-edit-section]').forEach((b) => b.onclick = () => editSection(b.dataset.editSection));
    $$('[data-delete-section]').forEach((b) => b.onclick = async () => {
      if (!confirm('حذف هذا القسم؟ يجب أولاً نقل محتواه وأقسامه الفرعية أو حذفها.')) return;
      try { await api(`/api/admin/cms/sections/${encodeURIComponent(b.dataset.deleteSection)}`, { method: 'DELETE' }); notify('#cmsSectionMsg', 'تم حذف القسم.'); await loadAll(); }
      catch (error) { notify('#cmsSectionMsg', error.message); }
    });
  }
  function renderItems() {
    const filtered = items.filter((item) => !$('#cmsTypeFilter').value || item.type === $('#cmsTypeFilter').value);
    $('#cmsItemList').innerHTML = filtered.length ? filtered.map((item) => {
      const section = flatten(sections).find((s) => s.id === item.section_id)?.title || 'دون قسم';
      const status = item.status === 'published' ? 'منشور' : item.status === 'private' ? 'خاص' : 'مسودة';
      return `<article class="cms-item-row"><div class="cms-item-meta"><b>${escape(item.title)}</b><small>${escape(labels[item.type] || item.type)} · ${escape(section)} · ${escape(status)}</small></div><span class="cms-badge ${escape(item.status)}">${escape(status)}</span><div class="cms-item-actions"><button type="button" data-edit-item="${escape(item.id)}">تعديل</button><button type="button" data-delete-item="${escape(item.id)}">حذف</button></div></article>`;
    }).join('') : '<div class="empty-state small">لا يوجد محتوى لهذا النوع حتى الآن.</div>';
    $$('[data-edit-item]').forEach((b) => b.onclick = () => editItem(b.dataset.editItem));
    $$('[data-delete-item]').forEach((b) => b.onclick = async () => {
      if (!confirm('حذف هذا المحتوى نهائيًا؟')) return;
      try { await api(`/api/admin/cms/items/${encodeURIComponent(b.dataset.deleteItem)}`, { method: 'DELETE' }); notify('#cmsItemMsg', 'تم حذف المحتوى.'); await loadAll(); resetItem(); }
      catch (error) { notify('#cmsItemMsg', error.message); }
    });
  }
  function renderMediaPicker(selected = '') {
    $('#cmsMediaPicker').innerHTML = '<option value="">اختر صورة أو ملفاً مرفوعاً</option>' + media.map((m) => `<option value="${escape(m.url)}" data-kind="${escape(m.kind || (m.mime?.startsWith('image/') ? 'image' : m.mime?.startsWith('video/') ? 'video' : 'document'))}" data-name="${escape(m.name)}" ${m.url === selected ? 'selected' : ''}>${escape(m.name)} (${escape(m.kind || m.mime || '')})</option>`).join('');
  }
  $('#cmsMediaPicker').onchange = () => {
    const selected = media.find((m) => m.url === $('#cmsMediaPicker').value);
    $('#cmsMediaAlt').value = selected?.alt || '';
    $('#cmsMediaDescription').value = selected?.description || '';
    $('#cmsSaveMediaMeta').hidden = !selected?.kind;
  };
  $('#cmsSaveMediaMeta').onclick = async () => {
    const selected = media.find((m) => m.url === $('#cmsMediaPicker').value);
    if (!selected?.kind) return notify('#cmsItemMsg', 'اختر ملفًا من مكتبة CMS أولًا.');
    try {
      await api(`/api/admin/cms/media/${encodeURIComponent(selected.id)}`, { method: 'PATCH', body: JSON.stringify({ alt: $('#cmsMediaAlt').value, description: $('#cmsMediaDescription').value }) });
      selected.alt = $('#cmsMediaAlt').value; selected.description = $('#cmsMediaDescription').value;
      notify('#cmsItemMsg', 'تم حفظ النص البديل والوصف.');
    } catch (error) { notify('#cmsItemMsg', error.message); }
  };
  async function loadAll() {
    try {
      [sections, items, media] = await Promise.all([
        api('/api/admin/cms/sections'), api('/api/admin/cms/items'),
        Promise.all([api('/api/admin/cms/media'), api('/api/admin/media')]).then(([a,b]) => [...a, ...b])
      ]);
      renderTree(); renderItems(); renderMediaPicker(); updateTypeFields();
    } catch (error) { notify('#cmsItemMsg', error.message); }
  }
  function editSection(id) {
    const node = flatten(sections).find((s) => s.id === id); if (!node) return;
    sectionEditing = id; $('#cmsSectionTitle').value = node.title; $('#cmsSectionDescription').value = node.description || ''; $('#cmsSectionParent').value = node.parentId || ''; $('#cmsSectionForm button[type="submit"]').textContent = 'حفظ تعديلات القسم'; $('#cmsCancelSectionEdit').hidden = false; renderTree();
  }
  function resetSection() { sectionEditing = ''; $('#cmsSectionForm').reset(); $('#cmsSectionParent').value = ''; $('#cmsSectionForm button[type="submit"]').textContent = 'إنشاء قسم'; $('#cmsCancelSectionEdit').hidden = true; renderTree(); }
  $('#cmsSectionForm').addEventListener('submit', async (event) => {
    event.preventDefault(); const payload = { title: $('#cmsSectionTitle').value, description: $('#cmsSectionDescription').value, parentId: $('#cmsSectionParent').value || null };
    try {
      if (sectionEditing) await api(`/api/admin/cms/sections/${encodeURIComponent(sectionEditing)}`, { method: 'PATCH', body: JSON.stringify(payload) });
      else await api('/api/admin/cms/sections', { method: 'POST', body: JSON.stringify(payload) });
      notify('#cmsSectionMsg', 'تم حفظ القسم.'); resetSection(); await loadAll();
    } catch (error) { notify('#cmsSectionMsg', error.message); }
  });
  $('#cmsCancelSectionEdit').onclick = resetSection;

  function updateTypeFields(data = null) {
    const type = $('#cmsItemType').value; const d = data || {};
    if (type === 'course') {
      $('#cmsTypeFields').innerHTML = `<div class="editor-grid"><label>الجمهور المستهدف<input data-type-data="targetAudience" value="${escape(d.targetAudience || '')}"></label><label>المستوى العلمي<input data-type-data="level" value="${escape(d.level || '')}"></label><label>المدة<input data-type-data="duration" value="${escape(d.duration || '')}"></label></div><label>أهداف الدورة<textarea data-type-data="objectives" rows="3">${escape((d.objectives || []).join('\n'))}</textarea></label>`;
    } else if (type === 'lesson') {
      const courses = items.filter((item) => item.type === 'course');
      $('#cmsTypeFields').innerHTML = `<div class="editor-grid"><label>الدورة التابعة لها<select data-type-data="courseId" id="cmsLessonCourse"><option value="">اختر دورة</option>${courses.map((c) => `<option value="${escape(c.id)}" ${c.id === (d.courseId || '') ? 'selected' : ''}>${escape(c.title)}</option>`).join('')}</select></label><label>ترتيب الدرس<input data-type-data="sortOrder" type="number" min="0" value="${Number(d.sortOrder) || 0}"></label></div>`;
    } else if (type === 'formulation') {
      const ingredients = Array.isArray(d.ingredients) && d.ingredients.length ? d.ingredients : [{ name: '', quantity: '', percentage: '' }];
      $('#cmsTypeFields').innerHTML = `<fieldset><legend>المكونات والنسب</legend><div class="recipe-table-wrap"><table class="recipe-table"><thead><tr><th>المكون</th><th>الكمية</th><th>النسبة %</th><th></th></tr></thead><tbody id="cmsIngredientRows">${ingredients.map((r) => ingredientRow(r)).join('')}</tbody></table></div><div class="recipe-total" id="cmsRecipeTotal">مجموع النسب <strong>0%</strong></div><button class="recipe-add" id="cmsAddIngredient" type="button">+ إضافة مكون</button></fieldset><div class="editor-grid"><label>خطوات التصنيع<textarea data-type-data="process" rows="3">${escape(d.process || '')}</textarea></label><label>ظروف التشغيل والمعالجة<textarea data-type-data="operatingConditions" rows="3">${escape(d.operatingConditions || '')}</textarea></label><label>المواصفات الفنية<textarea data-type-data="specifications" rows="3">${escape(d.specifications || '')}</textarea></label><label>ملاحظات<textarea data-type-data="notes" rows="3">${escape(d.notes || '')}</textarea></label></div>`;
      bindIngredientRows();
    } else if (type === 'project') {
      $('#cmsTypeFields').innerHTML = `<div class="editor-grid"><label>تاريخ التنفيذ<input data-type-data="performedAt" type="date" value="${escape(d.performedAt || '')}"></label><label>النتائج<textarea data-type-data="results" rows="3">${escape(d.results || '')}</textarea></label><label>المشكلة<textarea data-type-data="problem" rows="3">${escape(d.problem || '')}</textarea></label><label>الحل الهندسي<textarea data-type-data="engineeringSolution" rows="3">${escape(d.engineeringSolution || '')}</textarea></label><label>مراحل التنفيذ<textarea data-type-data="stages" rows="3">${escape((d.stages || []).join('\n'))}</textarea></label><label>صورة قبل التنفيذ<input data-type-data="beforeImage" value="${escape(d.beforeImage || '')}"><button class="recipe-add" type="button" data-use-media="beforeImage">استخدم الملف المحدد من المكتبة</button></label><label>صورة بعد التنفيذ<input data-type-data="afterImage" value="${escape(d.afterImage || '')}"><button class="recipe-add" type="button" data-use-media="afterImage">استخدم الملف المحدد من المكتبة</button></label></div>`;
      $$('[data-use-media]').forEach((button) => button.onclick = () => { const url = $('#cmsMediaPicker').value; if (!url) return notify('#cmsItemMsg', 'اختر صورة من المكتبة أولاً.'); $(`[data-type-data="${button.dataset.useMedia}"]`).value = url; });
    } else if (type === 'article') {
      $('#cmsTypeFields').innerHTML = `<label>المراجع والمصادر (مرجع في كل سطر)<textarea data-type-data="references" rows="3">${escape((d.references || []).join('\n'))}</textarea></label>`;
    } else {
      $('#cmsTypeFields').innerHTML = `<div class="editor-grid"><label>طريقة طلب الخدمة<input data-type-data="requestMethod" value="${escape(d.requestMethod || '')}" placeholder="نموذج التواصل أو واتساب"></label><label>مدة / نطاق الخدمة<input data-type-data="duration" value="${escape(d.duration || '')}"></label></div>`;
    }
  }
  function ingredientRow(row = {}) { return `<tr><td><input data-ingredient="name" value="${escape(row.name || '')}" aria-label="اسم المكون"></td><td><input data-ingredient="quantity" value="${escape(row.quantity || '')}" aria-label="كمية المكون"></td><td><input data-ingredient="percentage" type="number" min="0" max="100" step="0.0001" value="${row.percentage ?? ''}" aria-label="النسبة المئوية"></td><td><button class="cms-tree-action delete" data-remove-ingredient type="button" aria-label="حذف المكون">×</button></td></tr>`; }
  function calcTotal() {
    const sum = $$('[data-ingredient="percentage"]').reduce((n, input) => n + (Number(input.value) || 0), 0);
    const node = $('#cmsRecipeTotal'); if (!node) return;
    node.classList.toggle('invalid', Math.abs(sum - 100) > 0.01);
    node.querySelector('strong').textContent = `${sum.toFixed(4).replace(/\.?0+$/, '')}%${Math.abs(sum - 100) <= 0.01 ? ' · متوازن' : ' · يجب التحقق من المجموع'}`;
  }
  function bindIngredientRows() {
    const rows = $('#cmsIngredientRows'); if (!rows) return;
    rows.oninput = calcTotal;
    rows.onclick = (event) => { if (event.target.closest('[data-remove-ingredient]')) { event.target.closest('tr').remove(); calcTotal(); } };
    $('#cmsAddIngredient').onclick = () => { rows.insertAdjacentHTML('beforeend', ingredientRow()); calcTotal(); };
    calcTotal();
  }
  function typeDataFromForm() {
    const type = $('#cmsItemType').value;
    if (type === 'formulation') {
      const ingredients = [...$$('#cmsIngredientRows tr')].map((tr) => ({ name: tr.querySelector('[data-ingredient="name"]').value, quantity: tr.querySelector('[data-ingredient="quantity"]').value, percentage: tr.querySelector('[data-ingredient="percentage"]').value })).filter((r) => r.name.trim());
      const d = {}; $$('[data-type-data]').forEach((field) => d[field.dataset.typeData] = field.value.trim());
      return { ...d, ingredients };
    }
    const result = {};
    $$('[data-type-data]').forEach((field) => {
      const key = field.dataset.typeData;
      if (['objectives','references','stages'].includes(key)) result[key] = field.value.split('\n').map((x) => x.trim()).filter(Boolean);
      else if (key === 'sortOrder') result[key] = Number(field.value) || 0;
      else result[key] = field.value.trim();
    });
    if ($('#cmsLessonCourse')) result.courseId = $('#cmsLessonCourse').value;
    return result;
  }
  function resetItem() {
    $('#cmsItemForm').reset(); $('#cmsItemId').value = ''; $('#cmsEditor').innerHTML = ''; $('#cmsItemSection').value = '';
    $('#cmsItemStatus').value = 'draft'; $('#cmsItemType').value = 'article'; $('#cmsPublicLink').hidden = true; savedSlug = ''; updateTypeFields();
  }
  function editItem(id) {
    const item = items.find((x) => x.id === id); if (!item) return;
    $('#cmsItemId').value = item.id; $('#cmsItemType').value = item.type; updateTypeFields(item.typeData || {});
    $('#cmsItemTitle').value = item.title; $('#cmsItemSummary').value = item.summary || ''; $('#cmsItemStatus').value = item.status; $('#cmsItemSection').value = item.section_id || '';
    $('#cmsEditor').innerHTML = item.body_html || ''; savedSlug = item.slug; $('#cmsItemMsg').textContent = `تعديل: ${item.title}`;
    if (item.status === 'published') { $('#cmsPublicLink').href = `/content/${encodeURIComponent(item.slug)}`; $('#cmsPublicLink').hidden = false; }
    else $('#cmsPublicLink').hidden = true;
    $('#cmsItemForm').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  $('#cmsItemType').onchange = () => updateTypeFields();
  $('#cmsTypeFilter').onchange = renderItems;
  $('#cmsNewItem').onclick = resetItem;
  $('#cmsItemForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const payload = { type: $('#cmsItemType').value, sectionId: $('#cmsItemSection').value || null, title: $('#cmsItemTitle').value, summary: $('#cmsItemSummary').value, status: $('#cmsItemStatus').value, bodyHtml: $('#cmsEditor').innerHTML, typeData: typeDataFromForm() };
    const id = $('#cmsItemId').value;
    try {
      const result = await api(id ? `/api/admin/cms/items/${encodeURIComponent(id)}` : '/api/admin/cms/items', { method: id ? 'PATCH' : 'POST', body: JSON.stringify(payload) });
      const item = result.item; savedSlug = item.slug;
      notify('#cmsItemMsg', result.message || 'تم حفظ المحتوى.');
      if (item.status === 'published') { $('#cmsPublicLink').href = `/content/${encodeURIComponent(item.slug)}`; $('#cmsPublicLink').hidden = false; }
      else $('#cmsPublicLink').hidden = true;
      await loadAll(); $('#cmsItemId').value = item.id;
    } catch (error) { notify('#cmsItemMsg', error.message); }
  });
  $$('[data-command]').forEach((button) => button.onclick = () => { $('#cmsEditor').focus(); document.execCommand(button.dataset.command, false); });
  $('#cmsInsertTable').onclick = () => { $('#cmsEditor').focus(); document.execCommand('insertHTML', false, '<table><tbody><tr><th>العنصر</th><th>القيمة</th></tr><tr><td>—</td><td>—</td></tr></tbody></table><p><br></p>'); };
  $('#cmsInsertMedia').onclick = () => {
    const select = $('#cmsMediaPicker'); const url = select.value; if (!url) return notify('#cmsItemMsg', 'اختر ملفاً من مكتبة الوسائط أولاً.');
    const option = select.selectedOptions[0]; const kind = option.dataset.kind; const name = option.dataset.name;
    const safeUrl = escape(url); let html;
    if (kind === 'image') html = `<figure><img src="${safeUrl}" alt="${escape(name)}" loading="lazy"><figcaption>${escape(name)}</figcaption></figure><p><br></p>`;
    else if (kind === 'video') html = `<video controls preload="metadata"><source src="${safeUrl}" type="${url.toLowerCase().endsWith('.webm') ? 'video/webm' : 'video/mp4'}"></video><p><br></p>`;
    else html = `<p><a href="${safeUrl}" target="_blank" rel="noopener noreferrer">تحميل / فتح الملف: ${escape(name)}</a></p>`;
    $('#cmsEditor').focus(); document.execCommand('insertHTML', false, html);
  };
  function dataUrl(file) { return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => reject(new Error('تعذرت قراءة الملف.')); reader.readAsDataURL(file); }); }
  $('#cmsFileUpload').onchange = async () => {
    const file = $('#cmsFileUpload').files[0]; if (!file) return;
    notify('#cmsItemMsg', 'جارٍ رفع الملف والتحقق منه…');
    try {
      const result = await api('/api/admin/cms/media', { method: 'POST', body: JSON.stringify({ name: file.name, alt: $('#cmsMediaAlt').value, description: $('#cmsMediaDescription').value, fileData: await dataUrl(file) }) });
      media.unshift(result.asset); renderMediaPicker(result.asset.url); $('#cmsMediaPicker').value = result.asset.url; $('#cmsMediaPicker').dispatchEvent(new Event('change')); $('#cmsFileUpload').value = '';
      notify('#cmsItemMsg', result.message + ' اختر «إدراج في الشرح» لإضافته.');
    } catch (error) { notify('#cmsItemMsg', error.message); }
  };
  $('#cmsEditor').addEventListener('input', () => {
    const preview = $('#cmsPreviewBody'); if (preview) preview.innerHTML = $('#cmsEditor').innerHTML;
  });
  $('#cmsItemTitle').addEventListener('input', () => { const title = $('#cmsPreviewTitle'); if (title) title.textContent = $('#cmsItemTitle').value || 'معاينة المحتوى'; });
  $('[data-page="platform"]')?.addEventListener('click', () => loadAll());
  if ($('#cmsPreviewBody')) $('#cmsPreviewBody').innerHTML = '';
  renderMediaPicker();
})();
