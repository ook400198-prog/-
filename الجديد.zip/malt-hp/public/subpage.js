const $ = (selector) => document.querySelector(selector);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char]));
function setTheme(dark) { document.body.classList.toggle('dark-mode', dark); const button = $('#themeToggle'); if (button) button.textContent = dark ? '☀' : '☾'; localStorage.setItem('malt-theme', dark ? 'dark' : 'light'); }
setTheme(localStorage.getItem('malt-theme') === 'dark'); $('#themeToggle')?.addEventListener('click', () => setTheme(!document.body.classList.contains('dark-mode')));
function galleryImages(item) { return [item.image, ...(item.gallery || []).map((image) => typeof image === 'string' ? image : image.url)].filter(Boolean); }
function serviceCard(service, index) { return `<a class="service-card ${service.image ? 'has-service-image' : ''}" href="/service?id=${encodeURIComponent(service.id)}" style="--delay:${index * 60}ms">${service.image ? `<img class="service-card-image" src="${esc(service.imageThumbnail || service.image)}" alt="${esc(service.imageAlt || service.title)}" loading="lazy" onerror="this.src='/assets/image-fallback.svg'">` : ''}<span class="service-no">${String(service.id).padStart(2, '0')}</span><span class="service-icon">✦</span><h3>${esc(service.title)}</h3><div class="en">${esc(service.en)}</div><p>${esc(service.description)}</p></a>`; }
function entryCard(entry, index) { const images = galleryImages(entry); return `<article class="service-entry" style="--delay:${index * 80}ms">${images.map((image, imageIndex) => { const src = imageIndex === 0 ? entry.imageThumbnail || image : (entry.gallery?.[imageIndex - 1]?.thumbnailUrl || image); return `<img src="${esc(src)}" alt="${esc(entry.imageAlt || entry.title || '')}" loading="lazy" onerror="this.src='/assets/image-fallback.svg'" class="${imageIndex ? 'entry-gallery-image' : ''}">`; }).join('')}<small class="section-kicker">${esc(entry.date)}</small><h3>${esc(entry.title)}</h3><p>${esc(entry.body)}</p></article>`; }
async function renderPage() {
  try {
    const path = location.pathname;
    if (path.endsWith('/services.html')) {
      const data = await (await fetch('/api/content')).json(); $('#serviceGrid').innerHTML = (data.services || []).map(serviceCard).join(''); return;
    }
    if (path.endsWith('/posts.html')) {
      const data = await (await fetch('/api/content')).json();
      const posts = data.posts || [];
      $('#postsGrid').innerHTML = posts.length ? posts.map((post) => `<article class="post">${galleryImages(post).map((image, index) => { const src = index === 0 ? post.imageThumbnail || image : (post.gallery?.[index - 1]?.thumbnailUrl || image); return `<img src="${esc(src)}" alt="${esc(post.imageAlt || post.title)}" loading="lazy" onerror="this.src='/assets/image-fallback.svg'">`; }).join('')}<div class="post-body"><small class="section-kicker">${esc(post.date)}</small><h3>${esc(post.title)}</h3><p>${esc(post.description)}</p></div></article>`).join('') : '<div class="empty-posts">سيظهر المحتوى المنشور هنا بعد إضافته من لوحة الإدارة.</div>';
      return;
    }
    if (path === '/service') {
      const id = new URLSearchParams(location.search).get('id'); if (!id) return;
      const response = await fetch(`/api/service?id=${encodeURIComponent(id)}`); if (!response.ok) return;
      const service = await response.json(); document.body.classList.add('page-ready'); $('#serviceNo').textContent = `القسم ${String(service.id).padStart(2, '0')}`; $('#serviceTitle').textContent = service.title; $('#serviceEn').textContent = service.en; $('#serviceDescription').textContent = service.details || service.description; document.title = `${service.title} | MALT HP`;
      if (service.image) { $('#serviceVisual').innerHTML = `<img src="${esc(service.image)}" alt="${esc(service.imageAlt || service.title)}" onerror="this.src='/assets/image-fallback.svg'">`; }
      $('#subSections').innerHTML = (service.subSections || []).map((sub, index) => `<a class="subsection-card ${sub.image ? 'has-sub-image' : ''}" href="/subsection?serviceId=${encodeURIComponent(service.id)}&subId=${encodeURIComponent(sub.id)}" style="--delay:${index * 80}ms">${sub.image ? `<img src="${esc(sub.imageThumbnail || sub.image)}" alt="${esc(sub.imageAlt || sub.title)}" loading="lazy" onerror="this.src='/assets/image-fallback.svg'">` : ''}<span>${String(index + 1).padStart(2, '0')}</span><h3>${esc(sub.title)}</h3><p>${esc(sub.description)}</p><i>↗</i></a>`).join('') || '<div class="empty-posts">أضف الأقسام الفرعية من لوحة الإدارة.</div>';
      $('#serviceEntries').innerHTML = service.entries?.length ? service.entries.map(entryCard).join('') : '<div class="empty-posts">سيظهر هنا محتوى هذا القسم، المقالات، العروض أو الملفات التي ينشرها فريق الإدارة.</div>';
      return;
    }
    if (path === '/subsection') {
      const params = new URLSearchParams(location.search); const serviceId = params.get('serviceId'); const subId = params.get('subId');
      const response = await fetch(`/api/subsection?serviceId=${encodeURIComponent(serviceId || '')}&subId=${encodeURIComponent(subId || '')}`);
      if (!response.ok) { $('#subTitle').textContent = 'القسم غير موجود'; return; }
      const result = await response.json(); document.body.classList.add('page-ready'); $('#subNo').textContent = `مساحة ${String(result.subsection.id).split('-').pop().padStart(2, '0')}`; $('#subTitle').textContent = result.subsection.title; $('#subDescription').textContent = result.subsection.description || 'مساحة متخصصة للمحتوى والتحديثات.'; $('#serviceName').textContent = result.service.title; $('#backToService').href = `/service?id=${encodeURIComponent(result.service.id)}`; document.title = `${result.subsection.title} | ${result.service.title}`;
      if (result.subsection.image) $('#subVisual').innerHTML = `<img src="${esc(result.subsection.image)}" alt="${esc(result.subsection.imageAlt || result.subsection.title)}" onerror="this.src='/assets/image-fallback.svg'">`;
      $('#subEntries').innerHTML = result.entries.length ? result.entries.map(entryCard).join('') : '<div class="empty-posts">لم ينشر الأدمن محتوى داخل هذا القسم بعد. سيكون أول منشور هنا قريبًا.</div>';
    }
  } catch (error) { console.error('تعذر تحميل محتوى الصفحة:', error); }
}
renderPage();
