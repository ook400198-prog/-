(() => {
  const $ = (s) => document.querySelector(s);
  const escape = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const labels = { article: 'مقال / بحث', course: 'دورة تدريبية', lesson: 'درس', formulation: 'تركيبة غذائية', project: 'مشروع هندسي', service: 'خدمة / استشارة' };
  function safeUrl(value) { const v = String(value || ''); return v.startsWith('/uploads/') || v.startsWith('/assets/') || /^https:\/\//i.test(v) ? v : ''; }
  async function getItem(key) { const response = await fetch(`/api/public/cms/items/${encodeURIComponent(key)}`); const result = await response.json(); if (!response.ok) throw new Error(result.message || 'المحتوى غير متاح'); return result; }
  function details(item) {
    const d = item.typeData || {};
    if (item.type === 'course') return `<section class="type-facts course-facts"><h2>عن الدورة</h2><div class="fact-chips">${d.level ? `<span>المستوى: ${escape(d.level)}</span>` : ''}${d.duration ? `<span>المدة: ${escape(d.duration)}</span>` : ''}${d.targetAudience ? `<span>الفئة المستهدفة: ${escape(d.targetAudience)}</span>` : ''}</div>${d.objectives?.length ? `<h3>أهداف التعلم</h3><ul>${d.objectives.map((x) => `<li>${escape(x)}</li>`).join('')}</ul>` : ''}${item.lessons?.length ? `<h3>دروس الدورة</h3><ol class="course-lessons">${item.lessons.map((l) => `<li><a href="/content/${encodeURIComponent(l.slug)}">${escape(l.title)}</a>${l.summary ? `<small>${escape(l.summary)}</small>` : ''}</li>`).join('')}</ol>` : '<p class="muted-note">سيتم إضافة الدروس لاحقًا.</p>'}</section>`;
    if (item.type === 'lesson') return `<section class="type-facts"><p class="fact-chips">${d.duration ? `<span>المدة: ${escape(d.duration)}</span>` : ''}</p></section>`;
    if (item.type === 'formulation') return `<section class="type-facts recipe-detail"><h2>التركيبة والمكونات</h2><div class="recipe-summary">مجموع النسب المسجلة <b>${escape(d.percentageTotal ?? 0)}%</b>${Math.abs(Number(d.percentageTotal || 0) - 100) <= .01 ? '<span>متوازن</span>' : '<span class="warn">يحتاج تحققاً فنياً</span>'}</div><div class="recipe-table-wrap"><table class="reader-recipe-table"><thead><tr><th>المكون</th><th>الكمية</th><th>النسبة %</th></tr></thead><tbody>${(d.ingredients || []).map((r) => `<tr><td>${escape(r.name)}</td><td>${escape(r.quantity || '—')}</td><td>${r.percentage == null ? '—' : escape(r.percentage)}</td></tr>`).join('')}</tbody></table></div>${d.process ? `<h3>خطوات التصنيع</h3><div class="fact-copy">${escape(d.process).replace(/\n/g,'<br>')}</div>` : ''}${d.operatingConditions ? `<h3>ظروف التشغيل والمعالجة</h3><div class="fact-copy">${escape(d.operatingConditions).replace(/\n/g,'<br>')}</div>` : ''}${d.specifications ? `<h3>المواصفات الفنية</h3><div class="fact-copy">${escape(d.specifications).replace(/\n/g,'<br>')}</div>` : ''}${d.notes ? `<aside class="technical-note"><b>ملاحظات فنية</b><p>${escape(d.notes)}</p></aside>` : ''}</section>`;
    if (item.type === 'project') return `<section class="type-facts project-detail"><h2>ملف المشروع</h2>${d.performedAt ? `<p><b>تاريخ التنفيذ:</b> ${escape(d.performedAt)}</p>` : ''}${d.problem ? `<h3>المشكلة</h3><p>${escape(d.problem)}</p>` : ''}${d.engineeringSolution ? `<h3>الحل الهندسي</h3><p>${escape(d.engineeringSolution)}</p>` : ''}${d.stages?.length ? `<h3>مراحل التنفيذ</h3><ol>${d.stages.map((x) => `<li>${escape(x)}</li>`).join('')}</ol>` : ''}${d.results ? `<h3>النتائج</h3><p>${escape(d.results)}</p>` : ''}${safeUrl(d.beforeImage) || safeUrl(d.afterImage) ? `<div class="before-after">${safeUrl(d.beforeImage) ? `<figure><img src="${escape(safeUrl(d.beforeImage))}" alt="قبل التنفيذ" loading="lazy"><figcaption>قبل التنفيذ</figcaption></figure>` : ''}${safeUrl(d.afterImage) ? `<figure><img src="${escape(safeUrl(d.afterImage))}" alt="بعد التنفيذ" loading="lazy"><figcaption>بعد التنفيذ</figcaption></figure>` : ''}</div>` : ''}</section>`;
    if (item.type === 'article' && d.references?.length) return `<section class="type-facts references"><h2>المراجع والمصادر</h2><ol>${d.references.map((x) => `<li>${escape(x)}</li>`).join('')}</ol></section>`;
    if (item.type === 'service') return `<section class="type-facts"><h2>طلب الخدمة</h2><p>${escape(d.requestMethod || 'تواصل مع فريق MALT HP لطلب الخدمة أو الاستشارة.')}</p>${d.duration ? `<p><b>المدة أو النطاق:</b> ${escape(d.duration)}</p>` : ''}<a class="btn primary" href="/contact.html">تواصل معنا ↗</a></section>`;
    return '';
  }
  function makeToc() {
    const headings = [...document.querySelectorAll('#articleBody h2, #articleBody h3')];
    if (headings.length < 3) return '';
    const links = headings.map((h, i) => { const id = `section-${i + 1}`; h.id = id; return `<li class="${h.tagName === 'H3' ? 'nested' : ''}"><a href="#${id}">${escape(h.textContent)}</a></li>`; }).join('');
    return `<nav class="article-toc"><b>في هذا المحتوى</b><ol>${links}</ol></nav>`;
  }
  async function render() {
    const slug = decodeURIComponent(location.pathname.split('/').filter(Boolean).pop() || new URLSearchParams(location.search).get('id') || '');
    const item = await getItem(slug); const type = labels[item.type] || item.type; const path = item.section_id ? `<a href="/library?sectionId=${encodeURIComponent(item.section_id)}">العودة إلى القسم</a>` : '';
    document.title = `${item.title} | MALT HP`;
    const body = `<header class="reader-head kind-${escape(item.type)}"><span class="reader-type">${escape(type)}</span><h1>${escape(item.title)}</h1>${item.summary ? `<p>${escape(item.summary)}</p>` : ''}${item.published_at ? `<small>نُشر في ${escape(new Date(item.published_at).toLocaleDateString('ar'))}</small>` : ''}</header>${details(item)}<div class="reader-layout"><aside id="readerToc"></aside><article id="articleBody" class="reader-body">${item.body_html || '<p>لا يوجد شرح إضافي.</p>'}</article></div>${item.type === 'course' && item.lessons?.length ? '<a class="btn primary reader-next" href="/content/' + encodeURIComponent(item.lessons[0].slug) + '">ابدأ أول درس ↗</a>' : ''}<div class="reader-footer">${path}<a href="/library">استكشف المكتبة العلمية</a></div>`;
    $('#readerMount').innerHTML = body;
    $('#readerToc').innerHTML = makeToc();
    const toc = document.querySelector('.article-toc'); if (!toc) $('#readerToc').remove();
  }
  render().catch((error) => { $('#readerMount').innerHTML = `<div class="empty-state"><h2>المحتوى غير متاح</h2><p>${escape(error.message)}</p><a class="btn primary" href="/library">العودة إلى المكتبة</a></div>`; });
})();
