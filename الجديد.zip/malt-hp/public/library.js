(() => {
  const $ = (selector) => document.querySelector(selector);
  const escape = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const labels = { article: 'مقال / بحث', course: 'دورة تدريبية', lesson: 'درس', formulation: 'تركيبة غذائية', project: 'مشروع', service: 'خدمة / استشارة' };
  let selectedSection = new URLSearchParams(location.search).get('sectionId') || '';
  let sections = [];
  let items = [];
  const flatten = (nodes, path = [], out = []) => { for (const n of nodes || []) { const next = [...path, n.title]; out.push({ ...n, path: next.join(' / ') }); flatten(n.children, next, out); } return out; };
  async function getJson(url) { const response = await fetch(url); const body = await response.json(); if (!response.ok) throw new Error(body.message || 'تعذر تحميل المحتوى'); return body; }
  function renderTree() {
    const render = (nodes) => `<ul>${nodes.map((node) => `<li><button class="public-section-button ${selectedSection === node.id ? 'selected' : ''}" data-public-section="${escape(node.id)}">${escape(node.title)}</button>${node.children?.length ? render(node.children) : ''}</li>`).join('')}</ul>`;
    $('#publicSectionTree').innerHTML = `<button class="public-section-button ${!selectedSection ? 'selected' : ''}" data-public-section="">كل الأقسام</button>` + (sections.length ? render(sections) : '<p class="muted-note">لا توجد أقسام منشورة بعد.</p>');
    document.querySelectorAll('[data-public-section]').forEach((button) => button.onclick = () => { selectedSection = button.dataset.publicSection; renderTree(); refresh(); });
  }
  function renderCards() {
    const names = new Map(flatten(sections).map((s) => [s.id, s.path]));
    $('#resultCount').textContent = `${items.length} نتيجة`;
    $('#publicItems').innerHTML = items.length ? items.map((item) => {
      const extra = item.type === 'formulation' && item.typeData?.percentageTotal !== undefined ? `<span class="item-extra">مجموع النسب: ${escape(item.typeData.percentageTotal)}%</span>` : item.type === 'course' ? `<span class="item-extra">${escape(item.typeData?.level || 'دورة تعليمية')}</span>` : item.type === 'project' ? `<span class="item-extra">${escape(item.typeData?.performedAt || 'مشروع هندسي')}</span>` : '';
      return `<article class="knowledge-card kind-${escape(item.type)}"><div class="knowledge-card-kicker"><span>${escape(labels[item.type] || item.type)}</span>${names.get(item.section_id) ? `<small>${escape(names.get(item.section_id))}</small>` : ''}</div><h3><a href="/content/${encodeURIComponent(item.slug)}">${escape(item.title)}</a></h3><p>${escape(item.summary || item.body_html?.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').slice(0, 220) || '')}</p>${extra}<a class="knowledge-read" href="/content/${encodeURIComponent(item.slug)}">اقرأ المحتوى <span>←</span></a></article>`;
    }).join('') : '<div class="empty-state">لم نعثر على محتوى منشور يطابق اختيارك. جرّب كلمة بحث أخرى أو اختر نوعاً مختلفاً.</div>';
  }
  async function refresh() {
    const params = new URLSearchParams();
    const q = $('#cmsSearch').value.trim(); const type = $('#cmsTypeFilter').value;
    if (q) params.set('q', q); if (type) params.set('type', type); if (selectedSection) params.set('sectionId', selectedSection);
    $('#resultHeading').textContent = q ? `نتائج البحث: ${q}` : selectedSection ? (flatten(sections).find((s) => s.id === selectedSection)?.title || 'محتوى القسم') : (type ? labels[type] : 'آخر الإضافات');
    try { items = await getJson(`/api/public/cms/items?${params}`); renderCards(); }
    catch { $('#publicItems').innerHTML = '<div class="empty-state">تعذر تحميل المكتبة الآن. حدّث الصفحة بعد لحظات.</div>'; }
  }
  $('#cmsTypeFilter').onchange = refresh;
  $('#cmsSearchForm').onsubmit = (event) => { event.preventDefault(); refresh(); };
  let timer;
  $('#cmsSearch').oninput = () => { clearTimeout(timer); timer = setTimeout(refresh, 220); };
  getJson('/api/public/cms/sections').then((tree) => { sections = tree; renderTree(); return refresh(); }).catch(() => { renderTree(); });
})();
