(() => {
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char]));
  const menu = document.querySelector('.menu'); const nav = document.querySelector('.nav nav');
  menu?.addEventListener('click', () => nav?.classList.toggle('open'));
  nav?.addEventListener('click', (event) => { if (event.target.closest('a')) nav.classList.remove('open'); });
  const pageForPath = () => {
    if (location.pathname === '/') return 'home';
    if (location.pathname.endsWith('/about.html')) return 'about';
    if (location.pathname.endsWith('/services.html')) return 'services';
    if (location.pathname.endsWith('/posts.html')) return 'posts';
    if (location.pathname.endsWith('/contact.html')) return 'contact';
    if (location.pathname === '/service') return 'service';
    if (location.pathname === '/subsection') return 'subsection';
    return 'custom';
  };
  function openLightbox(url, alt) {
    const modal = document.createElement('div'); modal.className = 'image-lightbox'; modal.innerHTML = `<button aria-label="إغلاق">×</button><img src="${escapeHtml(url)}" alt="${escapeHtml(alt)}"><p>${escapeHtml(alt)}</p>`;
    modal.onclick = () => modal.remove(); document.body.append(modal);
  }
  async function init() {
    try {
      const response = await fetch('/api/content'); if (!response.ok) return;
      const data = await response.json(); const page = pageForPath(); const params = new URLSearchParams(location.search);
      const serviceId = params.get('id') || params.get('serviceId'); const subId = params.get('subId');
      let placements = (data.imagePlacements || []).filter((item) => item.page === page && item.targetType !== 'hero');
      if (page === 'service') placements = placements.filter((item) => !item.targetId || String(item.targetId) === String(serviceId));
      if (page === 'subsection') placements = placements.filter((item) => (!item.serviceId || String(item.serviceId) === String(serviceId)) && (!item.targetId || String(item.targetId) === String(subId)));
      else if (page === 'service') placements = placements.filter((item) => ['page', 'custom', 'serviceGallery'].includes(item.targetType));
      else if (page === 'subsection') placements = placements.filter((item) => ['page', 'custom', 'subsectionGallery'].includes(item.targetType));
      else placements = placements.filter((item) => ['page', 'custom'].includes(item.targetType));
      placements.sort((a, b) => (Number(a.order) || 0) - (Number(b.order) || 0));
      if (!placements.length) return;
      const main = document.querySelector('main'); if (!main) return;
      const gallery = document.createElement('section'); gallery.className = 'managed-gallery section'; gallery.setAttribute('aria-label', 'معرض الصور');
      gallery.innerHTML = `<div class="section-head"><div><div class="section-kicker">MALT HP / MEDIA</div><h2>معرض الصور</h2></div><p>صور مختارة من مكتبة الموقع.</p></div><div class="managed-gallery-grid">${placements.map((item) => `<figure><button type="button" data-lightbox="${escapeHtml(item.url)}" data-alt="${escapeHtml(item.alt || item.targetLabel || '')}"><img src="${escapeHtml(item.thumbnailUrl || item.url)}" alt="${escapeHtml(item.alt || item.targetLabel || 'صورة من MALT HP')}" loading="lazy" onerror="this.src='/assets/image-fallback.svg'"></button>${item.description ? `<figcaption>${escapeHtml(item.description)}</figcaption>` : ''}</figure>`).join('')}</div>`;
      main.append(gallery);
      gallery.querySelectorAll('[data-lightbox]').forEach((button) => button.addEventListener('click', () => openLightbox(button.dataset.lightbox, button.dataset.alt)));
    } catch (error) { console.warn('تعذر تحميل صور الموقع:', error); }
  }
  document.addEventListener('DOMContentLoaded', init);
})();
