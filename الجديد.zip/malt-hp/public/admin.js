let data = null;
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char]));
async function api(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json', 'X-MALT-Admin': '1', ...(options.headers || {}) }, ...options });
  const result = await response.json();
  if (!response.ok) throw Error(result.message || 'حدث خطأ');
  return result;
}
const fileData = async (file) => {
  if (!file) return '';
  const original = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => reject(Error('تعذرت قراءة الصورة.')); reader.readAsDataURL(file); });
  if (file.size < 1_500_000 || !window.createImageBitmap) return original;
  try {
    const bitmap = await createImageBitmap(file); const scale = Math.min(1, 2400 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas'); canvas.width = Math.round(bitmap.width * scale); canvas.height = Math.round(bitmap.height * scale);
    canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height); bitmap.close();
    const optimized = await new Promise((resolve) => canvas.toBlob(resolve, 'image/webp', 0.9));
    return optimized && optimized.size < file.size ? await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => reject(Error('تعذرت معالجة الصورة.')); reader.readAsDataURL(optimized); }) : original;
  } catch { return original; }
};
const thumbnailData = async (file) => {
  if (!file || !window.createImageBitmap) return '';
  try {
    const bitmap = await createImageBitmap(file); const scale = Math.min(1, 520 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas'); canvas.width = Math.max(1, Math.round(bitmap.width * scale)); canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height); bitmap.close();
    return canvas.toDataURL('image/webp', 0.78);
  } catch { return ''; }
};
function notice(id, text) { const node = $(id); if (!node) return; node.textContent = text; setTimeout(() => { if (node.textContent === text) node.textContent = ''; }, 4500); }
const labels = { overview: 'نظرة عامة', composer: 'منشور جديد', posts: 'كل المنشورات', media: 'إدارة صور الموقع', platform: 'المنصة العلمية', sections: 'الأقسام', settings: 'الإعدادات' };
function go(page) {
  $$('.cms-nav').forEach((node) => node.classList.toggle('active', node.dataset.page === page));
  $$('.cms-page').forEach((node) => node.classList.toggle('active', node.id === `${page}Page`));
  $('#pageCrumb').textContent = labels[page] || page; $('#pageTitle').textContent = labels[page] || page;
  if (page === 'media') { loadMedia(); renderPlacements(); }
  if (page === 'overview') loadOverview(); if (page === 'posts') renderAllPosts();
}
function renderServices() {
  $('#entryService').innerHTML = data.services.map((service) => `<option value="${service.id}">${esc(service.title)}</option>`).join('');
  renderSubSections(); renderMediaTargets();
}
function renderSubSections() {
  const service = data.services.find((item) => String(item.id) === String($('#entryService').value));
  $('#entrySubSection').innerHTML = '<option value="">كل القسم</option>' + (service?.subSections || []).map((item) => `<option value="${esc(item.id)}">${esc(item.title)}</option>`).join('');
}
function renderMediaTargets() {
  const serviceOptions = data.services.map((service) => `<option value="${service.id}">${esc(service.title)}</option>`).join('');
  $('#mediaService').innerHTML = serviceOptions;
  $('#mediaPost').innerHTML = (data.posts || []).map((post) => `<option value="${esc(post.id)}">${esc(post.title)}</option>`).join('') || '<option value="">لا توجد منشورات</option>';
  const renderSubTargets = () => {
    const service = data.services.find((item) => String(item.id) === String($('#mediaService').value));
    $('#mediaSubsection').innerHTML = (service?.subSections || []).map((sub) => `<option value="${esc(sub.id)}">${esc(sub.title)}</option>`).join('');
  };
  $('#mediaService').onchange = renderSubTargets; renderSubTargets();
  $('#mediaTargetType').onchange = () => {
    const kind = $('#mediaTargetType').value;
    $('#mediaEntityFields').hidden = !['service', 'subsection', 'serviceGallery', 'subsectionGallery'].includes(kind);
    $('#mediaPostFields').hidden = !['post', 'postGallery'].includes(kind);
    $('#mediaGenericFields').hidden = !['page', 'custom'].includes(kind);
    $('#mediaTargetHint').textContent = kind === 'hero' ? 'ستستبدل صورة الواجهة الحالية مع حفظ الصورة المختارة في مكتبة الوسائط.' : kind === 'service' ? 'تظهر الصورة على بطاقة الخدمة وصفحتها التفصيلية.' : kind === 'serviceGallery' ? 'إضافة صورة إلى معرض صور الخدمة؛ كرر العملية لإضافة عدة صور.' : kind === 'subsection' ? 'تظهر الصورة على بطاقة القسم الفرعي.' : kind === 'subsectionGallery' ? 'إضافة صورة إلى معرض القسم الفرعي؛ كرر العملية لإضافة عدة صور.' : kind === 'post' ? 'تعيين الصورة كغلاف للمنشور المحدد.' : kind === 'postGallery' ? 'إضافة الصورة إلى معرض المنشور المحدد.' : 'ستظهر الصورة في معرض ضمن الصفحة المحددة.';
  };
  $('#mediaTargetType').dispatchEvent(new Event('change'));
}
function postObjectList() { return data.services.flatMap((service) => (service.entries || []).map((entry) => ({ ...entry, service }))); }
function postMarkup(entry) {
  const images = [entry.image, ...(entry.gallery || []).map((image) => typeof image === 'string' ? image : image.url)].filter(Boolean);
  return `<article class="feed-card"><div class="feed-top"><div class="profile-avatar small">M</div><div><b>MALT HP</b><small>${esc(entry.date)} · ${esc(entry.service.title)}</small></div><button class="delete-btn" data-delete-entry="${entry.service.id}" data-entry-id="${entry.id}">حذف</button></div><h3>${esc(entry.title || 'منشور بدون عنوان')}</h3><p>${esc(entry.body)}</p>${images.map((image) => `<img src="${esc(image)}" alt="${esc(entry.imageAlt || entry.title || '')}" loading="lazy">`).join('')}<div class="feed-actions"><span>♡ إعجاب</span><span>◌ تعليق</span><span>↗ مشاركة</span></div></article>`;
}
function renderAllPosts() {
  const list = postObjectList(); const publicPosts = (data.posts || []).map((post) => `<article class="feed-card"><div class="feed-top"><div class="profile-avatar small">M</div><div><b>MALT HP</b><small>${esc(post.date || '')} · منشور عام</small></div><button class="delete-btn" data-delete-public="${esc(post.id)}">حذف</button></div><h3>${esc(post.title)}</h3><p>${esc(post.description)}</p>${[post.image, ...(post.gallery || []).map((item) => typeof item === 'string' ? item : item.url)].filter(Boolean).map((image) => `<img src="${esc(image)}" alt="${esc(post.imageAlt || post.title)}" loading="lazy">`).join('')}</article>`);
  $('#allPosts').innerHTML = publicPosts.concat(list.map(postMarkup)).join('') || '<div class="empty-state">لا توجد منشورات بعد. ابدأ بكتابة أول منشور.</div>';
  $$('[data-delete-entry]').forEach((button) => { button.onclick = async () => { if (!confirm('هل تريد حذف هذا المنشور؟')) return; try { await api(`/api/admin/service-entry/${button.dataset.deleteEntry}/${button.dataset.entryId}`, { method: 'DELETE' }); await load(); go('posts'); } catch (error) { alert(error.message); } }; });
  $$('[data-delete-public]').forEach((button) => { button.onclick = async () => { if (!confirm('حذف المنشور العام؟ ستبقى ملفاته في المكتبة.')) return; try { await api(`/api/admin/posts/${button.dataset.deletePublic}`, { method: 'DELETE' }); await load(); go('posts'); } catch (error) { alert(error.message); } }; });
}
function renderRecent() {
  const list = postObjectList().slice(0, 4);
  $('#recentPosts').innerHTML = list.length ? list.map((entry) => `<div class="recent-row">${entry.image ? `<img src="${esc(entry.image)}" alt="">` : '<div class="recent-icon">✎</div>'}<div><b>${esc(entry.title || 'منشور بدون عنوان')}</b><small>${esc(entry.date)} · ${esc(entry.service.title)}</small></div></div>`).join('') : '<div class="empty-state small">لا توجد منشورات حتى الآن.</div>';
}
async function loadOverview() { try { const metrics = await api('/api/admin/metrics'); $('#mVisits').textContent = metrics.totalVisits; $('#mPosts').textContent = metrics.posts; $('#mServices').textContent = metrics.services; $('#mEntries').textContent = metrics.entries; for (const [key, id] of Object.entries({ courses: 'mCourses', formulations: 'mFormulations', projects: 'mProjects', articles: 'mArticles', images: 'mImages', files: 'mFiles', sections: 'mSections' })) if ($(`#${id}`)) $(`#${id}`).textContent = metrics[key] || 0; if ($('#cmsRecentItems')) $('#cmsRecentItems').innerHTML = (metrics.cmsRecent || []).map((item) => `<div class="recent-row"><div class="recent-icon">◈</div><div><b>${esc(item.title)}</b><small>${esc(labels[item.type] || item.type)} · ${item.status === 'published' ? 'منشور' : item.status === 'private' ? 'خاص' : 'مسودة'}</small></div></div>`).join('') || '<div class="empty-state small">لا توجد عناصر علمية بعد.</div>'; renderRecent(); } catch {} }
function renderServicesEdit() {
  $('#servicesEdit').innerHTML = data.services.map((service, index) => `<article class="section-editor"><div class="section-editor-head"><div class="section-index">${String(index + 1).padStart(2, '0')}</div><div><b>${esc(service.title)}</b><small>${(service.entries || []).length} منشور · ${(service.subSections || []).length} مساحات</small></div><button class="delete-btn" data-delete-service="${service.id}">حذف القسم</button></div><div class="editor-grid"><input data-s="title" data-i="${index}" value="${esc(service.title)}" placeholder="اسم القسم"><input data-s="en" data-i="${index}" value="${esc(service.en)}" placeholder="الاسم بالإنجليزية"><input data-s="description" data-i="${index}" value="${esc(service.description)}" placeholder="وصف مختصر"><input data-s="details" data-i="${index}" value="${esc(service.details)}" placeholder="التفاصيل"></div><div class="sub-editors">${(service.subSections || []).map((sub, subIndex) => `<div><span>${subIndex + 1}</span><input data-sub="title" data-i="${index}" data-j="${subIndex}" value="${esc(sub.title)}"><input data-sub="description" data-i="${index}" data-j="${subIndex}" value="${esc(sub.description)}"><button class="mini-delete" data-delete-sub="${service.id}" data-sub-id="${esc(sub.id)}">×</button></div>`).join('')}</div></article>`).join('');
  $$('[data-delete-service]').forEach((button) => { button.onclick = async () => { if (data.services.length < 2) return notice('#serviceMsg', 'يجب إبقاء قسم واحد على الأقل.'); if (!confirm('حذف القسم؟ ستبقى الصور في المكتبة ولن تُحذف الملفات.')) return; try { await api(`/api/admin/service/${button.dataset.deleteService}`, { method: 'DELETE' }); await load(); } catch (error) { notice('#serviceMsg', error.message); } }; });
  $$('[data-delete-sub]').forEach((button) => { button.onclick = async () => { if (!confirm('حذف هذه المساحة؟')) return; try { await api(`/api/admin/subsection/${button.dataset.deleteSub}/${button.dataset.subId}`, { method: 'DELETE' }); await load(); } catch (error) { notice('#serviceMsg', error.message); } }; });
}
let mediaCache = [];
async function loadMedia() {
  try {
    mediaCache = await api('/api/admin/media'); const query = ($('#mediaSearch').value || '').trim().toLowerCase(); const category = $('#mediaCategory')?.value || 'all';
    const list = mediaCache.filter((item) => item.name.toLowerCase().includes(query) || (item.alt || '').toLowerCase().includes(query) || (item.description || '').toLowerCase().includes(query)).filter((item) => category === 'all' || (category === 'unused' ? item.usedIn.length === 0 : item.usedIn.some((usage) => usage.toLowerCase().includes(category))));
    $('#mediaGrid').innerHTML = list.length ? list.map((item) => `<article class="asset-card ${item.usedIn.length ? 'is-used' : ''}"><img src="${esc(item.thumbnailUrl || item.url)}" alt="${esc(item.alt)}" loading="lazy" data-select-media="${esc(item.id)}"><div class="asset-details"><b title="${esc(item.name)}">${item.builtin ? 'أصل المشروع · ' : ''}${esc(item.name)}</b><small>${(item.size / 1024).toFixed(1)} KB · ${new Date(item.date).toLocaleDateString('ar')}</small><small>${item.usedIn.length ? `مستخدمة: ${esc(item.usedIn.join('، '))}` : 'غير مستخدمة'}</small><div class="asset-actions"><button data-select-media="${esc(item.id)}">اختيار</button><button data-copy-media="${esc(item.url)}">نسخ الرابط</button><label class="replace-media">استبدال<input type="file" accept=".jpg,.jpeg,.png,.webp" data-replace-media="${esc(item.id)}"></label><button class="media-remove" data-delete-media="${esc(item.id)}" ${item.builtin ? 'disabled title="أصل صورة مضمّن في ملفات المشروع"' : item.usedIn.length ? 'disabled title="أزل ارتباط الصورة أولًا"' : ''}>حذف</button></div></div></article>`).join('') : '<div class="empty-state">لا توجد صور مطابقة. ارفع الصور أو غيّر عوامل البحث.</div>';
    $$('[data-select-media]').forEach((node) => node.onclick = () => selectMedia(node.dataset.selectMedia));
    $$('[data-copy-media]').forEach((node) => node.onclick = async () => { try { await navigator.clipboard.writeText(new URL(node.dataset.copyMedia, location.origin).href); notice('#mediaStatus', 'تم نسخ رابط الصورة.'); } catch { notice('#mediaStatus', 'تعذر النسخ؛ رابط الصورة: ' + node.dataset.copyMedia); } });
    $$('[data-delete-media]').forEach((node) => node.onclick = async () => { if (!confirm('حذف الصورة غير المستخدمة نهائيًا؟')) return; try { await api(`/api/admin/media/${encodeURIComponent(node.dataset.deleteMedia)}`, { method: 'DELETE' }); notice('#mediaStatus', 'تم حذف الصورة.'); await loadMedia(); } catch (error) { notice('#mediaStatus', error.message); } });
    $$('[data-replace-media]').forEach((input) => input.onchange = async () => { const file = input.files[0]; if (!file) return; try { await api(`/api/admin/media/${encodeURIComponent(input.dataset.replaceMedia)}`, { method: 'PUT', body: JSON.stringify({ imageData: await fileData(file), thumbnailData: await thumbnailData(file) }) }); notice('#mediaStatus', 'تم استبدال الملف مع الحفاظ على روابطه.'); await loadMedia(); } catch (error) { notice('#mediaStatus', error.message); } });
  } catch (error) { notice('#mediaStatus', error.message); }
}
function selectMedia(id) {
  const item = mediaCache.find((media) => media.id === id); if (!item) return;
  $('#selectedMedia').hidden = false; $('#selectedMediaImage').src = item.url; $('#selectedMediaName').textContent = `${item.name} · ${(item.size / 1024).toFixed(1)} KB`;
  $('#mediaAlt').value = item.alt || ''; $('#mediaDescription').value = item.description || ''; $('#selectedMediaId').value = item.id;
  $$('#mediaGrid .asset-card').forEach((card) => card.classList.toggle('selected', card.querySelector(`[data-select-media="${CSS.escape(id)}"]`) !== null));
}
function renderPlacements() {
  const placements = (data.imagePlacements || []).slice().sort((a, b) => a.order - b.order);
  $('#placementList').innerHTML = placements.length ? placements.map((item) => `<article class="placement-row" draggable="true" data-placement-id="${esc(item.id)}"><span class="drag-handle" aria-label="اسحب لإعادة الترتيب">⠿</span><img src="${esc(item.url)}" alt="${esc(item.alt)}"><div><b>${esc(item.pageLabel || item.page)} · ${esc(item.targetLabel || item.slot || 'معرض')}</b><small>${esc(item.alt || 'لا يوجد نص بديل')} · ترتيب ${item.order}</small><small>${esc(item.description || '')}</small></div><button class="media-remove" data-remove-placement="${esc(item.id)}">إزالة الارتباط</button></article>`).join('') : '<div class="empty-state">لم تربط أي صورة بموضع في الموقع بعد.</div>';
  let draggedId = '';
  $$('#placementList .placement-row').forEach((row) => {
    row.ondragstart = (event) => { draggedId = row.dataset.placementId; event.dataTransfer.effectAllowed = 'move'; row.classList.add('dragging'); };
    row.ondragend = () => row.classList.remove('dragging');
    row.ondragover = (event) => event.preventDefault();
    row.ondrop = async (event) => {
      event.preventDefault(); const rows = [...$$('#placementList .placement-row')]; const moving = rows.find((item) => item.dataset.placementId === draggedId); const target = row;
      if (!moving || moving === target) return; target.before(moving);
      const ids = [...$$('#placementList .placement-row')].map((item) => item.dataset.placementId);
      try { await api('/api/admin/placements/order', { method: 'PUT', body: JSON.stringify({ ids }) }); await load(); go('media'); }
      catch (error) { notice('#mediaStatus', error.message); }
    };
  });
  $$('[data-remove-placement]').forEach((button) => button.onclick = async () => { if (!confirm('إزالة هذا الارتباط؟ سيبقى ملف الصورة في المكتبة.')) return; try { await api(`/api/admin/placements/${encodeURIComponent(button.dataset.removePlacement)}`, { method: 'DELETE' }); await load(); go('media'); } catch (error) { notice('#mediaStatus', error.message); } });
}
function fillSettings() {
  const settings = data.settings;
  ['companyName', 'phone', 'email', 'location', 'heroTitle', 'heroAccent', 'intro'].forEach((key) => { if ($(`#${key}`)) $(`#${key}`).value = settings[key] || ''; });
  if ($('#maxUploadMB')) $('#maxUploadMB').value = settings.maxUploadMB || 8;
  if ($('#heroSettingsPreview')) $('#heroSettingsPreview').src = settings.heroImage || '/assets/image-fallback.svg';
}
async function load() {
  try { data = await api('/api/admin/content'); fillSettings(); renderServices(); renderServicesEdit(); renderAllPosts(); loadOverview(); }
  catch { $('#loginBox').style.display = 'flex'; $('#dashboard').classList.remove('active'); }
}
$('#loginForm').onsubmit = async (event) => { event.preventDefault(); try { await api('/api/login', { method: 'POST', body: JSON.stringify({ username: $('#username').value, password: $('#password').value }) }); $('#loginBox').style.display = 'none'; $('#dashboard').classList.add('active'); await load(); } catch (error) { notice('#loginMsg', error.message); } };
$$('[data-page]').forEach((button) => button.onclick = () => go(button.dataset.page)); $('#entryService').onchange = renderSubSections;
function preview() { $('#previewTitle').textContent = $('#entryTitle').value || 'عنوان المنشور سيظهر هنا'; $('#previewBody').textContent = $('#entryBody').value || 'اكتب نص المنشور لترى المعاينة المباشرة.'; }
$('#entryTitle').oninput = preview; $('#entryBody').oninput = preview;
$('#entryImage').onchange = async () => {
  const files = [...$('#entryImage').files]; const previews = [];
  for (const file of files.slice(0, 4)) previews.push(await fileData(file));
  $('#entryPreview').innerHTML = previews.map((src) => `<img src="${src}" alt="معاينة الصورة">`).join('');
  $('#previewImage').innerHTML = previews.slice(0, 1).map((src) => `<img src="${src}" alt="معاينة صورة المنشور">`).join('');
};
$('#entryForm').onsubmit = async (event) => {
  event.preventDefault(); try {
    const files = [...$('#entryImage').files].slice(0, 4); const imagesData = await Promise.all(files.map(async (file) => ({ imageData: await fileData(file), thumbnailData: await thumbnailData(file), name: file.name })));
    await api('/api/admin/service-entry', { method: 'POST', body: JSON.stringify({ serviceId: $('#entryService').value, subSectionId: $('#entrySubSection').value, title: $('#entryTitle').value, body: $('#entryBody').value, imagesData }) });
    notice('#entryMsg', 'تم نشر المحتوى وحفظ الصور.'); event.target.reset(); $('#entryPreview').innerHTML = ''; $('#previewImage').innerHTML = ''; preview(); await load();
  } catch (error) { notice('#entryMsg', error.message); }
};
$('#mediaUpload').onchange = async () => {
  const files = [...$('#mediaUpload').files]; if (!files.length) return;
  if (files.length > 4) { notice('#mediaStatus', 'الحد الأقصى 4 صور في الدفعة الواحدة.'); return; }
  try {
    const images = await Promise.all(files.map(async (file) => ({ imageData: await fileData(file), thumbnailData: await thumbnailData(file), name: file.name })));
    const result = await api('/api/admin/media', { method: 'POST', body: JSON.stringify({ images }) });
    notice('#mediaStatus', result.message); $('#mediaUpload').value = ''; await loadMedia();
  } catch (error) { notice('#mediaStatus', error.message); }
};
$('#mediaSearch').oninput = loadMedia; $('#mediaCategory').onchange = loadMedia;
$('#saveMediaMeta').onclick = async () => {
  const id = $('#selectedMediaId').value; if (!id) return notice('#mediaStatus', 'اختر صورة أولًا.');
  try { await api(`/api/admin/media/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ alt: $('#mediaAlt').value, description: $('#mediaDescription').value }) }); notice('#mediaStatus', 'تم حفظ الوصف والنص البديل.'); await loadMedia(); selectMedia(id); } catch (error) { notice('#mediaStatus', error.message); }
};
$('#assignMedia').onclick = async () => {
  const id = $('#selectedMediaId').value; const image = mediaCache.find((item) => item.id === id); if (!image) return notice('#mediaStatus', 'اختر صورة من المكتبة أولًا.');
  const kind = $('#mediaTargetType').value; const page = kind === 'hero' ? 'home' : ['service', 'serviceGallery'].includes(kind) ? 'service' : ['subsection', 'subsectionGallery'].includes(kind) ? 'subsection' : ['post', 'postGallery'].includes(kind) ? 'posts' : $('#mediaPageTarget').value;
  const service = data.services.find((item) => String(item.id) === String($('#mediaService').value)); const sub = service?.subSections.find((item) => String(item.id) === String($('#mediaSubsection').value));
  const post = data.posts.find((item) => String(item.id) === String($('#mediaPost').value));
  const labelsByPage = { home: 'الرئيسية', about: 'من نحن', services: 'الخدمات', service: 'صفحة خدمة', subsection: 'قسم فرعي', posts: 'المنشورات', contact: 'التواصل', custom: 'صفحة مستقبلية' };
  const targetLabel = kind === 'hero' ? 'صورة الواجهة الرئيسية' : ['service', 'serviceGallery'].includes(kind) ? `${service?.title}${kind === 'serviceGallery' ? ' / معرض الصور' : ''}` : ['subsection', 'subsectionGallery'].includes(kind) ? `${service?.title} / ${sub?.title}${kind === 'subsectionGallery' ? ' / معرض الصور' : ''}` : ['post', 'postGallery'].includes(kind) ? post?.title : ($('#mediaSlot').value.trim() || 'معرض صور');
  const payload = { url: image.url, alt: $('#mediaAlt').value || image.alt, description: $('#mediaDescription').value || image.description, page, pageLabel: labelsByPage[page], targetType: kind, targetId: ['service', 'serviceGallery'].includes(kind) ? service?.id : ['subsection', 'subsectionGallery'].includes(kind) ? sub?.id : ['post', 'postGallery'].includes(kind) ? post?.id : '', serviceId: ['subsection', 'subsectionGallery'].includes(kind) ? service?.id : '', targetLabel, slot: kind === 'hero' ? 'hero' : $('#mediaSlot').value.trim() || 'gallery', order: Number($('#mediaOrder').value) || 0 };
  try { const result = await api('/api/admin/placements', { method: 'POST', body: JSON.stringify(payload) }); notice('#mediaStatus', result.message); await load(); go('media'); } catch (error) { notice('#mediaStatus', error.message); }
};
$('#publicPostImages').onchange = async () => {
  const files = [...$('#publicPostImages').files].slice(0, 4); const previews = await Promise.all(files.map(fileData));
  $('#publicPostPreview').innerHTML = previews.map((src) => `<img src="${src}" alt="معاينة صورة المنشور">`).join('');
};
$('#publicPostForm').onsubmit = async (event) => {
  event.preventDefault();
  try {
    const files = [...$('#publicPostImages').files].slice(0, 4);
    const imagesData = await Promise.all(files.map(async (file) => ({ imageData: await fileData(file), thumbnailData: await thumbnailData(file), name: file.name })));
    const result = await api('/api/admin/publish', { method: 'POST', body: JSON.stringify({ title: $('#publicPostTitle').value, description: $('#publicPostDescription').value, imagesData }) });
    notice('#publicPostMsg', result.message); event.target.reset(); $('#publicPostPreview').innerHTML = ''; await load(); renderMediaTargets(); go('posts');
  } catch (error) { notice('#publicPostMsg', error.message); }
};
$('#addService').onclick = async () => { try { await api('/api/admin/service', { method: 'POST', body: JSON.stringify({ title: $('#newServiceTitle').value, en: $('#newServiceEn').value }) }); $('#newServiceTitle').value = ''; $('#newServiceEn').value = ''; notice('#serviceMsg', 'تمت إضافة القسم.'); await load(); } catch (error) { notice('#serviceMsg', error.message); } };
$('#saveServices').onclick = async () => {
  const services = data.services.map((service, index) => ({ ...service, title: $(`[data-s="title"][data-i="${index}"]`).value, en: $(`[data-s="en"][data-i="${index}"]`).value, description: $(`[data-s="description"][data-i="${index}"]`).value, details: $(`[data-s="details"][data-i="${index}"]`).value, subSections: (service.subSections || []).map((sub, subIndex) => ({ ...sub, title: $(`[data-sub="title"][data-i="${index}"][data-j="${subIndex}"]`).value, description: $(`[data-sub="description"][data-i="${index}"][data-j="${subIndex}"]`).value })) }));
  try { await api('/api/admin/content', { method: 'PUT', body: JSON.stringify({ services }) }); notice('#serviceMsg', 'تم حفظ تعديلات الأقسام.'); await load(); } catch (error) { notice('#serviceMsg', error.message); }
};
$('#settingsForm').onsubmit = async (event) => {
  event.preventDefault(); const file = $('#heroImage').files[0];
  try { await api('/api/admin/content', { method: 'PUT', body: JSON.stringify({ settings: { companyName: $('#companyName').value, phone: $('#phone').value, email: $('#email').value, location: $('#location').value, heroTitle: $('#heroTitle').value, heroAccent: $('#heroAccent').value, intro: $('#intro').value, maxUploadMB: $('#maxUploadMB').value, ...(file ? { heroImageData: await fileData(file), heroThumbnailData: await thumbnailData(file) } : {}) } }) }); notice('#saveMsg', 'تم حفظ الإعدادات.'); await load(); }
  catch (error) { notice('#saveMsg', error.message); }
};
$('#heroImage').onchange = async () => { const file = $('#heroImage').files[0]; if (file) $('#heroSettingsPreview').src = await fileData(file); };
$('#refreshBtn').onclick = load; $('#logout').onclick = async () => { await api('/api/admin/logout', { method: 'POST' }); location.reload(); };
function theme(dark) { document.body.classList.toggle('dark-mode', dark); localStorage.setItem('malt-theme', dark ? 'dark' : 'light'); }
theme(localStorage.getItem('malt-theme') === 'dark'); $('#themeToggle').onclick = () => theme(!document.body.classList.contains('dark-mode'));
(async () => { try { data = await api('/api/admin/content'); $('#loginBox').style.display = 'none'; $('#dashboard').classList.add('active'); await load(); } catch { $('#loginBox').style.display = 'flex'; } })();
