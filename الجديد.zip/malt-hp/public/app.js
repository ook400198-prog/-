const $ = (selector) => document.querySelector(selector);
const escapeHtml = (value) => String(value || '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char]));
function applyTheme(dark) { document.body.classList.toggle('dark-mode', dark); const button = $('#themeToggle'); if (button) button.textContent = dark ? '☀' : '☾'; localStorage.setItem('malt-theme', dark ? 'dark' : 'light'); }
applyTheme(localStorage.getItem('malt-theme') === 'dark'); $('#themeToggle')?.addEventListener('click', () => applyTheme(!document.body.classList.contains('dark-mode')));
async function getContent() { const response = await fetch('/api/content'); return response.json(); }
function renderStats(stats) { $('#stats').innerHTML = (stats || []).map((item) => `<div class="stat"><strong>${escapeHtml(item.value)}</strong><span>${escapeHtml(item.label)}</span></div>`).join(''); }
function renderServices(services) { $('#serviceGrid').innerHTML = (services || []).map((service) => `<a class="service-card ${service.image ? 'has-service-image' : ''}" href="/service?id=${encodeURIComponent(service.id)}">${service.image ? `<img class="service-card-image" src="${escapeHtml(service.imageThumbnail || service.image)}" alt="${escapeHtml(service.imageAlt || service.title)}" loading="lazy" onerror="this.src='/assets/image-fallback.svg'">` : ''}<span class="service-no">${String(service.id).padStart(2, '0')}</span><span class="service-icon">✦</span><h3>${escapeHtml(service.title)}</h3><div class="en">${escapeHtml(service.en)}</div><p>${escapeHtml(service.description)}</p></a>`).join(''); }
function renderPosts(posts) { $('#postGrid').innerHTML = posts?.length ? posts.slice(0, 3).map((post) => { const image = post.imageThumbnail || post.image || ''; return `<article class="post">${image ? `<img src="${escapeHtml(image)}" alt="${escapeHtml(post.imageAlt || post.title)}" onerror="this.src='/assets/image-fallback.svg'">` : ''}<div class="post-body"><small class="section-kicker">${escapeHtml(post.date)}</small><h3>${escapeHtml(post.title)}</h3><p>${escapeHtml(post.description)}</p></div></article>`; }).join('') : '<div class="empty-posts">سيظهر المحتوى الجديد هنا من لوحة الإدارة قريبًا.</div>'; }
async function init() {
  try {
    const data = await getContent();
    $('#heroTitle').textContent = data.settings.heroTitle || 'نحوّل المنتجات'; $('#heroAccent').textContent = data.settings.heroAccent || 'الغذائية إلى نجاح'; $('#intro').textContent = data.settings.intro;
    $('#heroImage').src = data.settings.heroImage || '/assets/alula-hero.jpg'; $('#heroImage').alt = data.settings.heroImageAlt || 'صورة الواجهة الرئيسية لـ MALT HP'; $('#heroImage').onerror = () => { $('#heroImage').src = '/assets/image-fallback.svg'; };
    $('#contactTitle').innerHTML = `${escapeHtml(data.settings.contactTitle || 'لنصنع نجاح مشروعك')}<br><span>معًا</span>`; $('#contactText').textContent = data.settings.contactText || ''; $('#contactDetails').textContent = `${data.settings.location || ''}${data.settings.email ? ` • ${data.settings.email}` : ''}`;
    renderStats(data.stats); renderServices(data.services); renderPosts(data.posts); $('#year').textContent = new Date().getFullYear();
  } catch (error) { console.error(error); }
}
$('#contactForm')?.addEventListener('submit', async (event) => { event.preventDefault(); const data = await getContent(); const phone = (data.settings.phone || '').replace(/\D/g, ''); const message = `مرحباً MALT HP،\nأنا: ${$('#contactName').value.trim()}\nاحتياجي: ${$('#contactNeed').value.trim()}`; window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, '_blank'); $('#formMsg').textContent = 'تم تجهيز رسالتك في واتساب.'; });
init();
