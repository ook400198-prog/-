const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const store = require('./db');
const cms = require('./cms-api');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const UPLOADS = path.resolve(process.env.MALT_UPLOAD_DIR || path.join(ROOT, 'uploads'));
const DATA_FILE = path.join(ROOT, 'data.json');
const PORT = Number(process.env.PORT) || 8080;
const DEFAULT_UPLOAD_MB = 8;
const sessions = new Map();
const visits = new Map();
const loginAttempts = new Map();
const ALLOWED_MIME = new Map([['image/jpeg', 'jpg'], ['image/png', 'png'], ['image/webp', 'webp']]);
if (!fs.existsSync(UPLOADS)) fs.mkdirSync(UPLOADS, { recursive: true });

function readData() {
  const data = store.readState();
  data.settings = data.settings || {};
  data.services = Array.isArray(data.services) ? data.services : [];
  data.posts = Array.isArray(data.posts) ? data.posts : [];
  data.stats = Array.isArray(data.stats) ? data.stats : [];
  data.mediaAssets = Array.isArray(data.mediaAssets) ? data.mediaAssets : [];
  data.imagePlacements = Array.isArray(data.imagePlacements) ? data.imagePlacements : [];
  data.services.forEach((service) => {
    service.entries = Array.isArray(service.entries) ? service.entries : [];
    service.subSections = Array.isArray(service.subSections) && service.subSections.length ? service.subSections : [
      { id: `${service.id}-1`, title: 'القسم الأول', description: 'مساحة مرنة للمحتوى المتخصص.' },
      { id: `${service.id}-2`, title: 'القسم الثاني', description: 'أضف هنا ما يهم جمهور هذا المجال.' },
      { id: `${service.id}-3`, title: 'القسم الثالث', description: 'منشورات وتحديثات وأفكار جديدة.' }
    ];
    service.gallery = Array.isArray(service.gallery) ? service.gallery : [];
    service.subSections.forEach((sub) => { sub.gallery = Array.isArray(sub.gallery) ? sub.gallery : []; });
  });
  data.posts.forEach((post) => { post.gallery = Array.isArray(post.gallery) ? post.gallery : []; });
  return data;
}
function writeData(data) {
  store.writeState(data);
}
function json(res, status, body) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(body)); }
function parseBody(req, limitBytes = 48 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    const declared = Number(req.headers['content-length'] || 0);
    if (declared > limitBytes) { req.resume(); reject(Object.assign(new Error('حجم الطلب أكبر من الحد المسموح.'), { status: 413 })); return; }
    req.on('data', (chunk) => { size += chunk.length; if (size > limitBytes) { req.resume(); reject(Object.assign(new Error('حجم الطلب أكبر من الحد المسموح.'), { status: 413 })); return; } chunks.push(chunk); });
    req.on('end', () => { try { resolve(size ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(Object.assign(new Error('تعذر قراءة بيانات الطلب.'), { status: 400 })); } });
    req.on('error', reject);
  });
}
function token() { return crypto.randomBytes(32).toString('hex'); }
function cookieToken(req) { return (req.headers.cookie || '').match(/(?:^|;\s*)malt_session=([^;]+)/)?.[1]; }
function isAdmin(req) { const value = cookieToken(req); const created = value && sessions.get(value); if (!created) return false; if (Date.now() - created > 12 * 60 * 60 * 1000) { sessions.delete(value); return false; } return true; }
function cleanText(value, max = 5000) { return String(value ?? '').trim().slice(0, max); }
function maxUploadBytes(data) { const mb = Number(data.settings.maxUploadMB); return Math.max(1, Math.min(25, Number.isFinite(mb) ? mb : DEFAULT_UPLOAD_MB)) * 1024 * 1024; }
function imageDimensions(bytes, mime) {
  if (mime === 'image/png' && bytes.length >= 24) return { width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20) };
  if (mime === 'image/jpeg') {
    let offset = 2;
    while (offset + 9 < bytes.length) {
      if (bytes[offset] !== 0xff) { offset += 1; continue; }
      const marker = bytes[offset + 1]; const length = bytes.readUInt16BE(offset + 2);
      if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) return { height: bytes.readUInt16BE(offset + 5), width: bytes.readUInt16BE(offset + 7) };
      if (length < 2) break; offset += 2 + length;
    }
  }
  return null;
}
function parseImageData(dataUrl, data) {
  const match = String(dataUrl || '').match(/^data:(image\/(?:png|jpeg|jpg|webp));base64,([A-Za-z0-9+/=\r\n]+)$/i);
  if (!match) throw Object.assign(new Error('الصيغ المسموحة: JPG وJPEG وPNG وWEBP.'), { status: 400 });
  const mime = match[1].toLowerCase() === 'image/jpg' ? 'image/jpeg' : match[1].toLowerCase();
  const bytes = Buffer.from(match[2].replace(/[\r\n]/g, ''), 'base64');
  if (!bytes.length || bytes.length > maxUploadBytes(data)) throw Object.assign(new Error(`حجم الصورة يتجاوز الحد (${Math.ceil(maxUploadBytes(data) / 1048576)} MB).`), { status: 413 });
  const valid = (mime === 'image/png' && bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])))
    || (mime === 'image/jpeg' && bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff)
    || (mime === 'image/webp' && bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP');
  if (!valid) throw Object.assign(new Error('امتداد الصورة لا يطابق محتوى الملف أو أن الملف تالف.'), { status: 400 });
  const dimensions = imageDimensions(bytes, mime);
  if (dimensions && (!dimensions.width || !dimensions.height || dimensions.width > 12000 || dimensions.height > 12000 || dimensions.width * dimensions.height > 40_000_000)) throw Object.assign(new Error('أبعاد الصورة كبيرة جدًا؛ الحد الأعلى 40 ميغابكسل.'), { status: 400 });
  return { bytes, mime, ext: ALLOWED_MIME.get(mime) };
}
function saveThumbnail(dataUrl, data, mainFile) {
  if (!dataUrl) return '';
  const { bytes, ext } = parseImageData(dataUrl, data);
  if (bytes.length > 2 * 1024 * 1024) throw Object.assign(new Error('الصورة المصغرة أكبر من الحد المسموح.'), { status: 413 });
  const thumbFile = `${path.parse(mainFile).name}-thumb.${ext}`;
  fs.writeFileSync(path.join(UPLOADS, thumbFile), bytes, { flag: 'w', mode: 0o640 });
  return `/uploads/${thumbFile}`;
}
function saveImage(dataUrl, data, originalName = 'image', thumbData = '') {
  const { bytes, mime, ext } = parseImageData(dataUrl, data);
  const file = `${Date.now()}-${crypto.randomBytes(12).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(UPLOADS, file), bytes, { flag: 'wx', mode: 0o640 });
  const name = path.basename(cleanText(originalName, 180)).replace(/[\u0000-\u001f]/g, '').slice(0, 180) || file;
  const record = { id: file, name, url: `/uploads/${file}`, thumbnailUrl: saveThumbnail(thumbData, data, file), size: bytes.length, mime, date: new Date().toISOString(), alt: '', description: '' };
  data.mediaAssets.unshift(record);
  return record;
}
function removeUpload(url) {
  if (!String(url || '').startsWith('/uploads/')) return;
  const file = path.basename(url);
  if (!/^[\w.-]+\.(?:png|jpe?g|webp)$/i.test(file)) return;
  const target = path.join(UPLOADS, file);
  if (fs.existsSync(target)) fs.unlinkSync(target);
  const stem = path.parse(file).name;
  for (const ext of ['webp', 'png', 'jpg', 'jpeg']) { const thumbPath = path.join(UPLOADS, `${stem}-thumb.${ext}`); if (fs.existsSync(thumbPath)) fs.unlinkSync(thumbPath); }
}
function references(data, url) {
  const found = [];
  if (data.settings.heroImage === url) found.push('صورة الواجهة الرئيسية');
  for (const placement of data.imagePlacements) if (placement.url === url) found.push(`${placement.pageLabel || placement.page} / ${placement.targetLabel || placement.slot || 'موضع صورة'}`);
  for (const service of data.services) {
    if (service.image === url) found.push(`الخدمات / ${service.title}`);
    (service.gallery || []).forEach((img) => { if ((typeof img === 'string' ? img : img.url) === url) found.push(`معرض ${service.title}`); });
    for (const sub of service.subSections || []) { if (sub.image === url) found.push(`قسم فرعي: ${sub.title}`); (sub.gallery || []).forEach((img) => { if ((typeof img === 'string' ? img : img.url) === url) found.push(`معرض ${sub.title}`); }); }
    for (const entry of service.entries || []) { if (entry.image === url) found.push(`محتوى ${service.title}: ${entry.title || ''}`); (entry.gallery || []).forEach((img) => { if ((typeof img === 'string' ? img : img.url) === url) found.push(`معرض ${entry.title || 'المحتوى'}`); }); }
  }
  for (const post of data.posts) { if (post.image === url) found.push(`منشور: ${post.title}`); (post.gallery || []).forEach((img) => { if ((typeof img === 'string' ? img : img.url) === url) found.push(`معرض ${post.title}`); }); }
  for (const row of store.db.prepare('SELECT title FROM cms_items WHERE body_html LIKE ? OR type_data LIKE ?').all(`%${url}%`, `%${url}%`)) found.push(`محتوى المنصة العلمية: ${row.title}`);
  return [...new Set(found)];
}
function replaceUrlInGallery(gallery, oldUrl, newUrl) {
  return (gallery || []).map((image) => typeof image === 'string' ? (image === oldUrl ? newUrl : image) : ({ ...image, url: image.url === oldUrl ? newUrl : image.url }));
}
function updateGalleryAlt(gallery, url, alt) {
  return (gallery || []).map((image) => typeof image === 'string' || image.url !== url ? image : ({ ...image, alt }));
}
function replaceImageReferences(data, oldUrl, newUrl, oldThumbUrl = '', newThumbUrl = '') {
  if (data.settings.heroImage === oldUrl) data.settings.heroImage = newUrl;
  if (data.settings.heroImageThumbnail === oldThumbUrl) data.settings.heroImageThumbnail = newThumbUrl;
  for (const placement of data.imagePlacements) { if (placement.url === oldUrl) placement.url = newUrl; if (placement.thumbnailUrl === oldThumbUrl) placement.thumbnailUrl = newThumbUrl; }
  for (const service of data.services) {
    if (service.image === oldUrl) service.image = newUrl;
    if (service.imageThumbnail === oldThumbUrl) service.imageThumbnail = newThumbUrl;
    service.gallery = replaceUrlInGallery(service.gallery, oldUrl, newUrl).map((item) => typeof item === 'string' || item.thumbnailUrl !== oldThumbUrl ? item : ({ ...item, thumbnailUrl: newThumbUrl }));
    for (const sub of service.subSections || []) { if (sub.image === oldUrl) sub.image = newUrl; if (sub.imageThumbnail === oldThumbUrl) sub.imageThumbnail = newThumbUrl; sub.gallery = replaceUrlInGallery(sub.gallery, oldUrl, newUrl).map((item) => typeof item === 'string' || item.thumbnailUrl !== oldThumbUrl ? item : ({ ...item, thumbnailUrl: newThumbUrl })); }
    for (const entry of service.entries || []) { if (entry.image === oldUrl) entry.image = newUrl; if (entry.imageThumbnail === oldThumbUrl) entry.imageThumbnail = newThumbUrl; entry.gallery = replaceUrlInGallery(entry.gallery, oldUrl, newUrl).map((item) => typeof item === 'string' || item.thumbnailUrl !== oldThumbUrl ? item : ({ ...item, thumbnailUrl: newThumbUrl })); }
  }
  for (const post of data.posts) { if (post.image === oldUrl) post.image = newUrl; if (post.imageThumbnail === oldThumbUrl) post.imageThumbnail = newThumbUrl; post.gallery = replaceUrlInGallery(post.gallery, oldUrl, newUrl).map((item) => typeof item === 'string' || item.thumbnailUrl !== oldThumbUrl ? item : ({ ...item, thumbnailUrl: newThumbUrl })); }
  for (const asset of data.mediaAssets) if (asset.url === oldUrl) { asset.url = newUrl; asset.thumbnailUrl = newThumbUrl; }
  store.db.prepare('UPDATE cms_items SET body_html = REPLACE(body_html, ?, ?), type_data = REPLACE(type_data, ?, ?), updated_at = ? WHERE body_html LIKE ? OR type_data LIKE ?').run(oldUrl, newUrl, oldUrl, newUrl, new Date().toISOString(), `%${oldUrl}%`, `%${oldUrl}%`);
}
function mediaList(data) {
  const records = new Map((data.mediaAssets || []).map((asset) => [asset.url, asset]));
  const managedCmsFiles = new Set(store.db.prepare('SELECT url FROM cms_media').all().map((asset) => asset.url));
  for (const file of fs.readdirSync(UPLOADS).filter((name) => /\.(?:png|jpe?g|webp)$/i.test(name) && !/-thumb\.(?:png|jpe?g|webp)$/i.test(name))) {
    const url = `/uploads/${file}`; if (managedCmsFiles.has(url)) continue; const stat = fs.statSync(path.join(UPLOADS, file));
    if (!records.has(url)) records.set(url, { id: file, name: file, url, size: stat.size, mime: mimeForFile(file), date: stat.mtime.toISOString(), alt: '', description: '' });
  }
  const assetDir = path.join(PUBLIC, 'assets');
  if (fs.existsSync(assetDir)) for (const file of fs.readdirSync(assetDir).filter((name) => /\.(?:png|jpe?g|webp)$/i.test(name) && !/logo/i.test(name))) {
    const url = `/assets/${file}`; const stat = fs.statSync(path.join(assetDir, file));
    if (!records.has(url)) records.set(url, { id: `asset:${file}`, name: file, url, size: stat.size, mime: mimeForFile(file), date: stat.mtime.toISOString(), alt: '', description: '', builtin: true });
  }
  return [...records.values()].map((item) => ({ ...item, usedIn: references(data, item.url) })).sort((a, b) => b.date.localeCompare(a.date));
}
function mimeForFile(file) { const ext = path.extname(file).toLowerCase(); return ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg'; }
function publicData(data) {
  const safe = JSON.parse(JSON.stringify(data));
  delete safe.settings.adminPassword; delete safe.settings.adminUsername;
  delete safe.mediaAssets;
  return safe;
}
function findService(data, id) { return data.services.find((service) => String(service.id) === String(id)); }
function uploadedUrl(data, url) { return mediaList(data).some((image) => image.url === url); }
function validatePlacement(data, b) {
  const allowedPages = new Set(['home', 'about', 'services', 'service', 'subsection', 'posts', 'contact', 'custom']);
  if (!allowedPages.has(b.page)) throw Object.assign(new Error('اختر صفحة صالحة.'), { status: 400 });
  const media = mediaList(data).find((image) => image.url === b.url);
  if (!media) throw Object.assign(new Error('اختر صورة موجودة في مكتبة الوسائط.'), { status: 400 });
  if (['service', 'serviceGallery'].includes(b.targetType) && !findService(data, b.targetId)) throw Object.assign(new Error('الخدمة المحددة غير موجودة.'), { status: 400 });
  if (['post', 'postGallery'].includes(b.targetType) && !data.posts.some((post) => String(post.id) === String(b.targetId))) throw Object.assign(new Error('المنشور المحدد غير موجود.'), { status: 400 });
  if (b.targetType === 'hero' && b.page !== 'home') throw Object.assign(new Error('صورة الواجهة الرئيسية مرتبطة بالصفحة الرئيسية فقط.'), { status: 400 });
  if (['subsection', 'subsectionGallery'].includes(b.targetType)) {
    const service = findService(data, b.serviceId); if (!service || !service.subSections.some((sub) => String(sub.id) === String(b.targetId))) throw Object.assign(new Error('القسم الفرعي المحدد غير موجود.'), { status: 400 });
  }
  return { page: b.page, pageLabel: cleanText(b.pageLabel, 80), targetType: cleanText(b.targetType, 30) || 'page', targetId: cleanText(b.targetId, 120), serviceId: cleanText(b.serviceId, 80), targetLabel: cleanText(b.targetLabel, 160), slot: cleanText(b.slot, 120) || 'gallery', url: b.url, thumbnailUrl: media.thumbnailUrl || '', alt: cleanText(b.alt, 300), description: cleanText(b.description, 1000), order: Math.max(0, Number(b.order) || 0), createdAt: new Date().toISOString() };
}

async function api(req, res, url) {
  const publicCmsHandled = await cms.publicApi(req, res, url);
  if (publicCmsHandled) return;
  if (url.pathname === '/api/content' && req.method === 'GET') return json(res, 200, publicData(readData()));
  if (url.pathname === '/api/service' && req.method === 'GET') {
    const service = findService(readData(), url.searchParams.get('id'));
    return service ? json(res, 200, service) : json(res, 404, { message: 'الخدمة غير موجودة.' });
  }
  if (url.pathname === '/api/subsection' && req.method === 'GET') {
    const data = readData(); const service = findService(data, url.searchParams.get('serviceId'));
    const sub = service?.subSections?.find((item) => String(item.id) === String(url.searchParams.get('subId')));
    if (!service || !sub) return json(res, 404, { message: 'القسم الفرعي غير موجود.' });
    return json(res, 200, { service: { id: service.id, title: service.title }, subsection: sub, entries: service.entries.filter((entry) => !entry.subSectionId || String(entry.subSectionId) === String(sub.id)) });
  }
  if (url.pathname === '/api/login' && req.method === 'POST') {
    if (!process.env.ADMIN_USERNAME || String(process.env.ADMIN_PASSWORD || '').length < 12) return json(res, 503, { ok: false, message: 'لم تُضبط بيانات مدير آمنة. عيّن ADMIN_USERNAME وADMIN_PASSWORD (12 حرفًا على الأقل) في البيئة.' });
    const ip = req.socket.remoteAddress || 'unknown'; const now = Date.now(); const attempt = loginAttempts.get(ip) || { count: 0, until: now };
    if (attempt.until > now && attempt.count >= 8) return json(res, 429, { ok: false, message: 'محاولات كثيرة. حاول بعد دقيقة.' });
    const b = await parseBody(req, 32 * 1024);
    if (store.authenticate(b.username, b.password)) {
      loginAttempts.delete(ip); const session = token(); sessions.set(session, now);
      const forwardedProto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
      const isHttps = Boolean(req.socket.encrypted) || (process.env.TRUST_PROXY === 'true' && forwardedProto === 'https');
      const cookiePolicy = isHttps ? 'SameSite=None; Secure' : 'SameSite=Lax';
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Set-Cookie': `malt_session=${session}; HttpOnly; ${cookiePolicy}; Path=/; Max-Age=43200` });
      return res.end(JSON.stringify({ ok: true }));
    }
    attempt.count += 1; attempt.until = now + 60_000; loginAttempts.set(ip, attempt);
    return json(res, 401, { ok: false, message: 'اسم المستخدم أو كلمة المرور غير صحيحة.' });
  }
  if (!url.pathname.startsWith('/api/admin/')) return json(res, 404, { message: 'المسار غير موجود' });
  if (!isAdmin(req)) return json(res, 401, { ok: false, message: 'انتهت الجلسة، يرجى تسجيل الدخول من جديد.' });
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const origin = req.headers.origin;
    const originHost = origin ? (() => { try { return new URL(origin).host; } catch { return ''; } })() : '';
    const fetchSite = String(req.headers['sec-fetch-site'] || '').toLowerCase();
    if ((origin && originHost !== req.headers.host) || fetchSite === 'cross-site' || (!origin && req.headers['x-malt-admin'] !== '1')) {
      return json(res, 403, { ok: false, message: 'رفض الطلب غير المطابق لنطاق لوحة الإدارة.' });
    }
  }
  const data = readData();
  const cmsHandled = await cms.adminApi(req, res, url);
  if (cmsHandled) return;
  if (url.pathname === '/api/admin/content' && req.method === 'GET') return json(res, 200, data);
  if (url.pathname === '/api/admin/media' && req.method === 'GET') return json(res, 200, mediaList(data));
  if (url.pathname === '/api/admin/media' && req.method === 'POST') {
    const b = await parseBody(req, Math.min(48 * 1024 * 1024, maxUploadBytes(data) * 6 + 1024 * 1024));
    const incoming = Array.isArray(b.images) ? b.images : [{ imageData: b.imageData, name: b.name, thumbnailData: b.thumbnailData }];
    if (!incoming.length || incoming.length > 4) return json(res, 400, { ok: false, message: 'ارفع من صورة واحدة إلى 4 صور في الدفعة الواحدة.' });
    const uploaded = incoming.map((image) => saveImage(image.imageData, data, image.name || 'image', image.thumbnailData || ''));
    writeData(data); return json(res, 201, { ok: true, images: uploaded, image: uploaded[0], message: `تم رفع ${uploaded.length} صورة وحفظها في المكتبة.` });
  }
  const mediaMatch = url.pathname.match(/^\/api\/admin\/media\/([^/]+)$/);
  if (mediaMatch && req.method === 'PATCH') {
    const file = path.basename(decodeURIComponent(mediaMatch[1])); const record = mediaList(data).find((item) => item.id === file || path.basename(item.url) === file);
    if (!record) return json(res, 404, { ok: false, message: 'الصورة غير موجودة.' });
    const b = await parseBody(req, 256 * 1024); const asset = data.mediaAssets.find((item) => item.url === record.url) || { ...record };
    asset.alt = cleanText(b.alt, 300); asset.description = cleanText(b.description, 1000); asset.name = cleanText(b.name, 180) || asset.name;
    for (const placement of data.imagePlacements) if (placement.url === record.url) { placement.alt = asset.alt; placement.description = asset.description; }
    if (data.settings.heroImage === record.url) data.settings.heroImageAlt = asset.alt;
    for (const service of data.services) {
      if (service.image === record.url) service.imageAlt = asset.alt;
      service.gallery = updateGalleryAlt(service.gallery, record.url, asset.alt);
      for (const sub of service.subSections || []) { if (sub.image === record.url) sub.imageAlt = asset.alt; sub.gallery = updateGalleryAlt(sub.gallery, record.url, asset.alt); }
      for (const entry of service.entries || []) { if (entry.image === record.url) entry.imageAlt = asset.alt; entry.gallery = updateGalleryAlt(entry.gallery, record.url, asset.alt); }
    }
    for (const post of data.posts) { if (post.image === record.url) post.imageAlt = asset.alt; post.gallery = updateGalleryAlt(post.gallery, record.url, asset.alt); }
    data.mediaAssets = data.mediaAssets.filter((item) => item.url !== asset.url); data.mediaAssets.unshift(asset); writeData(data);
    return json(res, 200, { ok: true, message: 'تم حفظ بيانات الصورة.' });
  }
  if (mediaMatch && req.method === 'PUT') {
    const file = path.basename(decodeURIComponent(mediaMatch[1])); const record = mediaList(data).find((item) => path.basename(item.url) === file);
    if (!record) return json(res, 404, { ok: false, message: 'الصورة غير موجودة.' });
    const b = await parseBody(req, Math.min(48 * 1024 * 1024, Math.ceil(maxUploadBytes(data) * 1.6) + 4 * 1024 * 1024)); const { bytes, mime, ext } = parseImageData(b.imageData, data);
    const replacementFile = `${Date.now()}-${crypto.randomBytes(12).toString('hex')}.${ext}`; const replacementUrl = `/uploads/${replacementFile}`;
    fs.writeFileSync(path.join(UPLOADS, replacementFile), bytes, { flag: 'wx', mode: 0o640 });
    const oldThumbUrl = record.thumbnailUrl || ''; const replacementThumbUrl = saveThumbnail(b.thumbnailData, data, replacementFile);
    replaceImageReferences(data, record.url, replacementUrl, oldThumbUrl, replacementThumbUrl);
    const asset = data.mediaAssets.find((item) => item.url === replacementUrl) || { ...record };
    Object.assign(asset, { id: replacementFile, name: cleanText(b.name, 180) || record.name, url: replacementUrl, thumbnailUrl: replacementThumbUrl, size: bytes.length, mime, date: new Date().toISOString() }); delete asset.builtin;
    data.mediaAssets = data.mediaAssets.filter((item) => item.url !== replacementUrl); data.mediaAssets.unshift(asset); writeData(data); removeUpload(record.url);
    return json(res, 200, { ok: true, url: replacementUrl, message: 'تم استبدال الصورة وحفظ الارتباطات بالمحتوى.' });
  }
  if (mediaMatch && req.method === 'DELETE') {
    const file = path.basename(decodeURIComponent(mediaMatch[1])); const record = mediaList(data).find((item) => path.basename(item.url) === file);
    if (!record) return json(res, 404, { ok: false, message: 'الصورة غير موجودة.' });
    if (record.builtin) return json(res, 403, { ok: false, message: 'أصول المشروع الأصلية لا تُحذف من المكتبة.' });
    const usedIn = references(data, record.url);
    if (usedIn.length) return json(res, 409, { ok: false, usedIn, message: `لا يمكن حذف الصورة لأنها مستخدمة في: ${usedIn.join('، ')}. أزل الارتباط أولًا.` });
    removeUpload(record.url); data.mediaAssets = data.mediaAssets.filter((item) => item.url !== record.url); writeData(data);
    return json(res, 200, { ok: true, message: 'تم حذف الصورة غير المستخدمة.' });
  }
  if (url.pathname === '/api/admin/placements' && req.method === 'POST') {
    const b = await parseBody(req, 256 * 1024); const placement = validatePlacement(data, b);
    if (placement.targetType === 'hero') data.imagePlacements = data.imagePlacements.filter((item) => item.targetType !== 'hero');
    if (placement.targetType === 'service') data.imagePlacements = data.imagePlacements.filter((item) => !(item.targetType === 'service' && String(item.targetId) === String(placement.targetId)));
    if (placement.targetType === 'subsection') data.imagePlacements = data.imagePlacements.filter((item) => !(item.targetType === 'subsection' && String(item.serviceId) === String(placement.serviceId) && String(item.targetId) === String(placement.targetId)));
    if (placement.targetType === 'hero') { data.settings.heroImage = placement.url; data.settings.heroImageAlt = placement.alt; }
    if (placement.targetType === 'service') { const service = findService(data, placement.targetId); service.image = placement.url; service.imageThumbnail = placement.thumbnailUrl; service.imageAlt = placement.alt; }
    if (placement.targetType === 'subsection') { const service = findService(data, placement.serviceId); const sub = service.subSections.find((item) => String(item.id) === placement.targetId); sub.image = placement.url; sub.imageThumbnail = placement.thumbnailUrl; sub.imageAlt = placement.alt; }
    if (placement.targetType === 'serviceGallery') { const service = findService(data, placement.targetId); service.gallery = Array.isArray(service.gallery) ? service.gallery : []; service.gallery.push({ url: placement.url, thumbnailUrl: placement.thumbnailUrl, alt: placement.alt, order: placement.order }); }
    if (placement.targetType === 'subsectionGallery') { const service = findService(data, placement.serviceId); const sub = service.subSections.find((item) => String(item.id) === placement.targetId); sub.gallery = Array.isArray(sub.gallery) ? sub.gallery : []; sub.gallery.push({ url: placement.url, thumbnailUrl: placement.thumbnailUrl, alt: placement.alt, order: placement.order }); }
    if (placement.targetType === 'post') { const post = data.posts.find((item) => String(item.id) === String(placement.targetId)); data.imagePlacements = data.imagePlacements.filter((item) => !(item.targetType === 'post' && String(item.targetId) === String(placement.targetId))); post.image = placement.url; post.imageAlt = placement.alt; }
    if (placement.targetType === 'postGallery') { const post = data.posts.find((item) => String(item.id) === String(placement.targetId)); post.gallery = Array.isArray(post.gallery) ? post.gallery : []; post.gallery.push({ url: placement.url, thumbnailUrl: placement.thumbnailUrl, alt: placement.alt, order: placement.order }); }
    placement.id = crypto.randomUUID(); data.imagePlacements.push(placement); writeData(data);
    return json(res, 201, { ok: true, placement, message: 'تم ربط الصورة بالمكان المحدد.' });
  }
  if (url.pathname === '/api/admin/placements/order' && req.method === 'PUT') {
    const b = await parseBody(req, 256 * 1024); const ids = Array.isArray(b.ids) ? b.ids : [];
    ids.forEach((id, order) => { const placement = data.imagePlacements.find((item) => item.id === id); if (placement) placement.order = order; });
    writeData(data); return json(res, 200, { ok: true, message: 'تم حفظ ترتيب الصور.' });
  }
  const placementMatch = url.pathname.match(/^\/api\/admin\/placements\/([^/]+)$/);
  if (placementMatch && req.method === 'DELETE') {
    const id = decodeURIComponent(placementMatch[1]); const removed = data.imagePlacements.find((item) => item.id === id);
    if (!removed) return json(res, 404, { ok: false, message: 'الارتباط غير موجود.' });
    data.imagePlacements = data.imagePlacements.filter((item) => item.id !== id);
    if (removed?.targetType === 'hero' && data.settings.heroImage === removed.url) { data.settings.heroImage = ''; data.settings.heroImageThumbnail = ''; }
    if (removed?.targetType === 'service') { const service = findService(data, removed.targetId); if (service?.image === removed.url) { service.image = ''; service.imageThumbnail = ''; service.imageAlt = ''; } }
    if (removed?.targetType === 'subsection') { const service = findService(data, removed.serviceId); const sub = service?.subSections.find((item) => String(item.id) === removed.targetId); if (sub?.image === removed.url) { sub.image = ''; sub.imageThumbnail = ''; sub.imageAlt = ''; } }
    if (removed?.targetType === 'serviceGallery') { const service = findService(data, removed.targetId); if (service) service.gallery = (service.gallery || []).filter((image) => (typeof image === 'string' ? image : image.url) !== removed.url); }
    if (removed?.targetType === 'subsectionGallery') { const service = findService(data, removed.serviceId); const sub = service?.subSections.find((item) => String(item.id) === removed.targetId); if (sub) sub.gallery = (sub.gallery || []).filter((image) => (typeof image === 'string' ? image : image.url) !== removed.url); }
    if (removed?.targetType === 'post') { const post = data.posts.find((item) => String(item.id) === String(removed.targetId)); if (post?.image === removed.url) { post.image = ''; post.imageAlt = ''; } }
    if (removed?.targetType === 'postGallery') { const post = data.posts.find((item) => String(item.id) === String(removed.targetId)); if (post) post.gallery = (post.gallery || []).filter((image) => (typeof image === 'string' ? image : image.url) !== removed.url); }
    writeData(data); return json(res, 200, { ok: true, message: 'أزيل ارتباط الصورة فقط؛ بقي الملف في المكتبة.' });
  }
  if (url.pathname === '/api/admin/content' && req.method === 'PUT') {
    const b = await parseBody(req);
    if (b.settings) {
      const next = { ...b.settings };
      if (b.settings.heroImageData) { const image = saveImage(b.settings.heroImageData, data, 'hero', b.settings.heroThumbnailData || ''); next.heroImage = image.url; next.heroImageThumbnail = image.thumbnailUrl; delete next.heroImageData; delete next.heroThumbnailData; }
      if (b.settings.maxUploadMB !== undefined) next.maxUploadMB = Math.max(1, Math.min(25, Number(b.settings.maxUploadMB) || DEFAULT_UPLOAD_MB));
    data.settings = { ...data.settings, ...next };
    }
    if (Array.isArray(b.stats)) data.stats = b.stats.map((s) => ({ value: cleanText(s.value, 30), label: cleanText(s.label, 80) }));
    if (Array.isArray(b.services)) data.services = b.services.map((s, index) => ({ ...s, id: Number(s.id) || index + 1, title: cleanText(s.title, 160), en: cleanText(s.en, 160), description: cleanText(s.description, 500), details: cleanText(s.details, 4000), entries: Array.isArray(s.entries) ? s.entries : [], gallery: Array.isArray(s.gallery) ? s.gallery : [], subSections: Array.isArray(s.subSections) ? s.subSections.map((sub, subIndex) => ({ ...sub, id: sub.id || `${Number(s.id) || index + 1}-${subIndex + 1}`, title: cleanText(sub.title, 160), description: cleanText(sub.description, 500), gallery: Array.isArray(sub.gallery) ? sub.gallery : [] })) : [] }));
    writeData(data); return json(res, 200, { ok: true, message: 'تم حفظ التغييرات بنجاح.' });
  }
  if (url.pathname === '/api/admin/service' && req.method === 'POST') {
    const b = await parseBody(req, 256 * 1024); const title = cleanText(b.title, 160);
    if (!title) return json(res, 400, { ok: false, message: 'اسم القسم مطلوب.' });
    const id = data.services.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0) + 1;
    data.services.push({ id, title, en: cleanText(b.en, 160), description: cleanText(b.description, 500), details: cleanText(b.details, 4000), entries: [], gallery: [], subSections: [{ id: `${id}-1`, title: 'القسم الأول', description: 'مساحة مرنة للمحتوى المتخصص.', gallery: [] }, { id: `${id}-2`, title: 'القسم الثاني', description: 'أضف هنا ما يهم جمهور هذا المجال.', gallery: [] }, { id: `${id}-3`, title: 'القسم الثالث', description: 'منشورات وتحديثات وأفكار جديدة.', gallery: [] }] });
    writeData(data); return json(res, 200, { ok: true, message: 'تمت إضافة القسم.' });
  }
  if (url.pathname.startsWith('/api/admin/service/') && req.method === 'DELETE') {
    const id = Number(url.pathname.split('/').pop()); const service = findService(data, id);
    if (!service) return json(res, 404, { ok: false, message: 'القسم غير موجود.' });
    data.services = data.services.filter((item) => Number(item.id) !== id); data.imagePlacements = data.imagePlacements.filter((item) => !(['service', 'serviceGallery'].includes(item.targetType) && String(item.targetId) === String(id)) && !(['subsection', 'subsectionGallery'].includes(item.targetType) && String(item.serviceId) === String(id))); writeData(data); return json(res, 200, { ok: true });
  }
  if (url.pathname === '/api/admin/subsection' && req.method === 'POST') {
    const b = await parseBody(req, 256 * 1024); const service = findService(data, b.serviceId); const title = cleanText(b.title, 160);
    if (!service || !title) return json(res, 400, { ok: false, message: 'اختر قسمًا واكتب اسم القسم الفرعي.' });
    service.subSections.push({ id: `${service.id}-${Date.now()}`, title, description: cleanText(b.description, 500), gallery: [] });
    writeData(data); return json(res, 200, { ok: true, message: 'تمت إضافة القسم الفرعي.' });
  }
  if (url.pathname.startsWith('/api/admin/subsection/') && req.method === 'DELETE') {
    const [, , , , serviceId, subId] = url.pathname.split('/'); const service = findService(data, serviceId);
    if (!service) return json(res, 404, { ok: false });
    service.subSections = service.subSections.filter((item) => String(item.id) !== String(subId)); data.imagePlacements = data.imagePlacements.filter((item) => !(['subsection', 'subsectionGallery'].includes(item.targetType) && String(item.serviceId) === String(serviceId) && String(item.targetId) === String(subId))); writeData(data); return json(res, 200, { ok: true });
  }
  if (url.pathname === '/api/admin/publish' && req.method === 'POST') {
    const b = await parseBody(req); const title = cleanText(b.title, 160); const description = cleanText(b.description, 4000);
    if (!title || !description) return json(res, 400, { ok: false, message: 'العنوان والوصف مطلوبان.' });
    const images = Array.isArray(b.imagesData) ? b.imagesData.slice(0, 4).map((item) => saveImage(item.imageData, data, item.name || 'post', item.thumbnailData || '')) : (b.imageData ? [saveImage(b.imageData, data, b.imageName || 'post', b.thumbnailData || '')] : []);
    data.posts.unshift({ id: Date.now(), title, description, image: images[0]?.url || '', imageThumbnail: images[0]?.thumbnailUrl || '', imageAlt: cleanText(b.imageAlt, 300), gallery: images.slice(1).map((image, order) => ({ url: image.url, thumbnailUrl: image.thumbnailUrl, alt: '', order })), date: new Date().toLocaleDateString('ar-SA') });
    writeData(data); return json(res, 200, { ok: true, message: 'تم نشر المنشور بنجاح.' });
  }
  if (url.pathname.startsWith('/api/admin/posts/') && req.method === 'DELETE') {
    const id = Number(url.pathname.split('/').pop()); data.posts = data.posts.filter((p) => Number(p.id) !== id); data.imagePlacements = data.imagePlacements.filter((item) => !(['post', 'postGallery'].includes(item.targetType) && String(item.targetId) === String(id))); writeData(data); return json(res, 200, { ok: true });
  }
  if (url.pathname === '/api/admin/service-entry' && req.method === 'POST') {
    const b = await parseBody(req); const service = findService(data, b.serviceId);
    if (!service || !cleanText(b.title, 160) || !cleanText(b.body, 4000)) return json(res, 400, { ok: false, message: 'اختر قسمًا وأدخل عنوان المحتوى ونصه.' });
    const images = Array.isArray(b.imagesData) ? b.imagesData.slice(0, 4).map((item) => saveImage(item.imageData, data, item.name || 'service', item.thumbnailData || '')) : (b.imageData ? [saveImage(b.imageData, data, b.imageName || 'service', b.thumbnailData || '')] : []);
    service.entries.unshift({ id: Date.now(), subSectionId: cleanText(b.subSectionId, 120), title: cleanText(b.title, 160), body: cleanText(b.body, 4000), image: images[0]?.url || '', imageThumbnail: images[0]?.thumbnailUrl || '', imageAlt: images[0]?.alt || '', gallery: images.slice(1).map((image, order) => ({ url: image.url, thumbnailUrl: image.thumbnailUrl, alt: '', order })), date: new Date().toLocaleDateString('ar-SA') });
    writeData(data); return json(res, 200, { ok: true, message: 'تمت إضافة المحتوى إلى القسم.' });
  }
  if (url.pathname.startsWith('/api/admin/service-entry/') && req.method === 'DELETE') {
    const [, , , , serviceId, entryId] = url.pathname.split('/'); const service = findService(data, serviceId);
    if (!service) return json(res, 404, { ok: false }); service.entries = service.entries.filter((e) => Number(e.id) !== Number(entryId)); writeData(data); return json(res, 200, { ok: true });
  }
  if (url.pathname === '/api/admin/metrics' && req.method === 'GET') {
    const now = Date.now(); const active = [...visits.values()].filter((time) => now - time < 15 * 60000).length;
    const entries = data.services.reduce((sum, service) => sum + service.entries.length, 0);
    const typeCounts = Object.fromEntries(store.db.prepare('SELECT type, COUNT(*) AS count FROM cms_items GROUP BY type').all().map((row) => [row.type, row.count]));
    const fileCounts = Object.fromEntries(store.db.prepare('SELECT kind, COUNT(*) AS count FROM cms_media GROUP BY kind').all().map((row) => [row.kind, row.count]));
    const cmsRecent = store.db.prepare('SELECT id, title, type, status, updated_at FROM cms_items ORDER BY updated_at DESC LIMIT 5').all();
    return json(res, 200, { totalVisits: visits.size, activeNow: active, posts: data.posts.length, services: data.services.length, entries,
      courses: typeCounts.course || 0, formulations: typeCounts.formulation || 0, projects: typeCounts.project || 0, articles: typeCounts.article || 0,
      sections: store.db.prepare('SELECT COUNT(*) AS count FROM cms_sections').get().count,
      images: mediaList(data).length + (fileCounts.image || 0), files: (fileCounts.document || 0) + (fileCounts.video || 0), cmsRecent });
  }
  if (url.pathname === '/api/admin/logout' && req.method === 'POST') { const value = cookieToken(req); if (value) sessions.delete(value); const forwardedProto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase(); const secure = Boolean(req.socket.encrypted) || (process.env.TRUST_PROXY === 'true' && forwardedProto === 'https'); const cookiePolicy = secure ? 'SameSite=None; Secure' : 'SameSite=Lax'; res.setHeader('Set-Cookie', `malt_session=; Max-Age=0; HttpOnly; ${cookiePolicy}; Path=/`); return json(res, 200, { ok: true }); }
  return json(res, 404, { message: 'المسار غير موجود' });
}

const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.pdf': 'application/pdf', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation', '.mp4': 'video/mp4', '.webm': 'video/webm' };
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    visits.set(`${req.socket.remoteAddress}-${Date.now()}`, Date.now());
    let requested = url.pathname;
    if (requested === '/') requested = '/index.html';
    if (requested === '/admin') requested = '/admin.html';
    if (requested === '/service') requested = '/service.html';
    if (requested === '/subsection') requested = '/subsection.html';
    if (requested === '/library') requested = '/library.html';
    if (requested === '/content' || requested.startsWith('/content/')) requested = '/reader.html';
    const file = path.resolve(PUBLIC, `.${requested}`);
    if (!file.startsWith(`${PUBLIC}${path.sep}`) && file !== PUBLIC) return json(res, 403, { message: 'Forbidden' });
    if (fs.existsSync(file) && fs.statSync(file).isFile()) {
      res.writeHead(200, { 'Content-Type': mime[path.extname(file).toLowerCase()] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
      if (path.extname(file).toLowerCase() === '.html' && path.basename(file) !== 'admin.html') {
        let html = fs.readFileSync(file, 'utf8');
        if (!html.includes('/site-images.js')) html = html.replace('</body>', '<script src="/site-images.js" defer></script></body>');
        return res.end(html);
      }
      return fs.createReadStream(file).pipe(res);
    }
    if (requested.startsWith('/uploads/')) {
      const name = path.basename(requested); const upload = path.join(UPLOADS, name);
      if (/^[\w.-]+\.(?:png|jpe?g|webp|pdf|docx|xlsx|pptx|mp4|webm)$/i.test(name) && fs.existsSync(upload)) { res.writeHead(200, { 'Content-Type': mime[path.extname(upload).toLowerCase()], 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'public, max-age=31536000, immutable', 'Content-Disposition': 'inline' }); return fs.createReadStream(upload).pipe(res); }
    }
    res.writeHead(404); res.end('Not found');
  } catch (error) { console.error(error); json(res, error.status || 500, { message: error.status ? error.message : 'حدث خطأ داخلي.' }); }
});
server.listen(PORT, '0.0.0.0', () => console.log(`MALT HP website running at http://localhost:${PORT}`));
