const path = require('path');
const fs = require('fs');
const { db, databasePath } = require('../db');

const output = path.resolve(process.argv[2] || path.join(__dirname, '..', 'backups', `malt-hp-${new Date().toISOString().replace(/[:.]/g, '-')}.sqlite`));
fs.mkdirSync(path.dirname(output), { recursive: true, mode: 0o750 });
db.backup(output).then(() => {
  fs.chmodSync(output, 0o600);
  console.log(`Backup written: ${output}`);
  console.log(`Source database: ${databasePath}`);
  db.close();
}).catch((error) => {
  console.error('Backup failed:', error.message);
  db.close();
  process.exitCode = 1;
});
