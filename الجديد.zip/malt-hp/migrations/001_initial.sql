CREATE TABLE IF NOT EXISTS site_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  data_json TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admin_users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cms_sections (
  id TEXT PRIMARY KEY,
  parent_id TEXT REFERENCES cms_sections(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('published', 'draft')),
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cms_sections_parent_order ON cms_sections(parent_id, sort_order, title);

CREATE TABLE IF NOT EXISTS cms_items (
  id TEXT PRIMARY KEY,
  section_id TEXT REFERENCES cms_sections(id) ON DELETE SET NULL,
  type TEXT NOT NULL CHECK (type IN ('article', 'course', 'lesson', 'formulation', 'project', 'service')),
  course_id TEXT REFERENCES cms_items(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  summary TEXT NOT NULL DEFAULT '',
  body_html TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'private')),
  type_data TEXT NOT NULL DEFAULT '{}',
  sort_order INTEGER NOT NULL DEFAULT 0,
  published_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cms_items_type_status_date ON cms_items(type, status, published_at DESC);
CREATE INDEX IF NOT EXISTS idx_cms_items_section ON cms_items(section_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_cms_items_course ON cms_items(course_id, sort_order);

CREATE TABLE IF NOT EXISTS cms_media (
  id TEXT PRIMARY KEY,
  original_name TEXT NOT NULL,
  storage_name TEXT NOT NULL UNIQUE,
  url TEXT NOT NULL UNIQUE,
  mime TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('image', 'video', 'document')),
  size_bytes INTEGER NOT NULL,
  alt_text TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cms_media_kind_date ON cms_media(kind, created_at DESC);
