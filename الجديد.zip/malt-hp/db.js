const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const ROOT = __dirname;
const configuredPath = process.env.MALT_DATABASE_PATH || path.join(ROOT, 'data', 'malt-hp.sqlite');
fs.mkdirSync(path.dirname(path.resolve(configuredPath)), { recursive: true, mode: 0o750 });
const previousUmask = process.umask(0o077);
let db;
try { db = new Database(configuredPath); } finally { process.umask(previousUmask); }
try { fs.chmodSync(path.resolve(configuredPath), 0o600); } catch {}
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');
db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)');

const migrations = [
  { version: 1, file: path.join(ROOT, 'migrations', '001_initial.sql') }
];
for (const migration of migrations) {
  const applied = db.prepare('SELECT 1 FROM schema_migrations WHERE version = ?').get(migration.version);
  if (applied) continue;
  const sql = fs.readFileSync(migration.file, 'utf8');
  db.transaction(() => {
    db.exec(sql);
    db.prepare('INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)').run(migration.version, new Date().toISOString());
  })();
}

const stateRow = db.prepare('SELECT id FROM site_state WHERE id = 1').get();
if (!stateRow) {
  const legacyPath = path.join(ROOT, 'data.json');
  const initial = JSON.parse(fs.readFileSync(legacyPath, 'utf8'));
  if (initial.settings) {
    delete initial.settings.adminUsername;
    delete initial.settings.adminPassword;
  }
  db.prepare('INSERT INTO site_state(id, data_json, updated_at) VALUES (1, ?, ?)').run(JSON.stringify(initial), new Date().toISOString());
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derived = crypto.scryptSync(password, salt, 64);
  return `${salt.toString('hex')}:${derived.toString('hex')}`;
}
function verifyPassword(password, stored) {
  try {
    const [saltHex, hashHex] = String(stored).split(':');
    const salt = Buffer.from(saltHex, 'hex');
    const expected = Buffer.from(hashHex, 'hex');
    if (salt.length !== 16 || expected.length !== 64) return false;
    const actual = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(actual, expected);
  } catch { return false; }
}

const envUser = String(process.env.ADMIN_USERNAME || '').trim();
const envPassword = String(process.env.ADMIN_PASSWORD || '');
if (envUser && envPassword.length >= 12) {
  const row = db.prepare('SELECT id FROM admin_users WHERE username = ?').get(envUser);
  if (row) {
    db.prepare('UPDATE admin_users SET password_hash = ?, active = 1, updated_at = ? WHERE username = ?')
      .run(hashPassword(envPassword), new Date().toISOString(), envUser);
  } else {
    db.prepare('INSERT INTO admin_users(id, username, password_hash, active, created_at, updated_at) VALUES (?, ?, ?, 1, ?, ?)')
      .run(crypto.randomUUID(), envUser, hashPassword(envPassword), new Date().toISOString(), new Date().toISOString());
  }
  db.prepare('UPDATE admin_users SET active = CASE WHEN username = ? THEN 1 ELSE 0 END, updated_at = ?').run(envUser, new Date().toISOString());
} else {
  db.prepare('UPDATE admin_users SET active = 0, updated_at = ?').run(new Date().toISOString());
}

const statements = {
  getState: db.prepare('SELECT data_json FROM site_state WHERE id = 1'),
  putState: db.prepare('UPDATE site_state SET data_json = ?, updated_at = ? WHERE id = 1'),
  getAdmin: db.prepare('SELECT id, username, password_hash, active FROM admin_users WHERE username = ?')
};
function readState() {
  const row = statements.getState.get();
  return JSON.parse(row.data_json);
}
function writeState(value) {
  if (value.settings) {
    delete value.settings.adminUsername;
    delete value.settings.adminPassword;
  }
  statements.putState.run(JSON.stringify(value), new Date().toISOString());
}
function authenticate(username, password) {
  const user = statements.getAdmin.get(String(username || '').trim());
  return Boolean(user && user.active && verifyPassword(String(password || ''), user.password_hash));
}

module.exports = { db, readState, writeState, authenticate, hashPassword, verifyPassword, databasePath: path.resolve(configuredPath) };
