const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { mkdtemp, rm } = require('node:fs/promises');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');

let temp;
let child;
let port;
let cookie = '';
const username = 'test-admin';
const password = 'Testing-Only-Password-456!';
const base = () => `http://127.0.0.1:${port}`;

async function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => { const value = server.address().port; server.close((error) => error ? reject(error) : resolve(value)); });
  });
}
async function startServer() {
  child = spawn(process.execPath, ['server.js'], {
    cwd: path.resolve(__dirname, '..'),
    env: { ...process.env, PORT: String(port), ADMIN_USERNAME: username, ADMIN_PASSWORD: password,
      MALT_DATABASE_PATH: path.join(temp, 'test.sqlite'), MALT_UPLOAD_DIR: path.join(temp, 'uploads'), CMS_MAX_FILE_MB: '5' },
    stdio: ['ignore', 'ignore', 'pipe']
  });
  let stderr = '';
  child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
  for (let attempt = 0; attempt < 100; attempt++) {
    if (child.exitCode !== null) throw new Error(`Server exited early: ${stderr}`);
    try { const response = await fetch(`${base()}/api/content`); if (response.ok) return; } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  child.kill('SIGKILL');
  throw new Error(`Server did not start: ${stderr}`);
}
async function stopServer() {
  if (!child || child.exitCode !== null) return;
  const proc = child;
  proc.kill('SIGTERM');
  await Promise.race([new Promise((resolve) => proc.once('exit', resolve)), new Promise((resolve) => setTimeout(resolve, 5000))]);
  if (proc.exitCode === null) proc.kill('SIGKILL');
}
async function login() {
  const response = await fetch(`${base()}/api/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username, password }) });
  assert.equal(response.status, 200);
  cookie = (response.headers.get('set-cookie') || '').split(';')[0];
  assert.match(cookie, /^malt_session=/);
}
async function api(url, options = {}) {
  const headers = { 'content-type': 'application/json', ...(options.admin ? { cookie, 'X-MALT-Admin': '1' } : {}), ...(options.headers || {}) };
  const response = await fetch(`${base()}${url}`, { ...options, headers });
  const body = await response.json().catch(() => ({}));
  return { response, body };
}
async function createSection(title, parentId = null) {
  const { response, body } = await api('/api/admin/cms/sections', { admin: true, method: 'POST', body: JSON.stringify({ title, parentId, description: `${title} description` }) });
  assert.equal(response.status, 201, JSON.stringify(body));
  return body.section;
}
async function createItem(payload) {
  const { response, body } = await api('/api/admin/cms/items', { admin: true, method: 'POST', body: JSON.stringify(payload) });
  assert.equal(response.status, 201, JSON.stringify(body));
  return body.item;
}

test('CMS integration: auth, hierarchy, content types, security, media, legacy state and restart persistence', { timeout: 90_000 }, async (t) => {
  temp = await mkdtemp(path.join(os.tmpdir(), 'malt-hp-integration-'));
  port = await freePort();
  try {
    await startServer();
    await t.test('legacy site routes and initial JSON migration remain available', async () => {
      const [home, adminPage, library, content, routes, result] = await Promise.all([
        fetch(`${base()}/`), fetch(`${base()}/admin`), fetch(`${base()}/library`), fetch(`${base()}/content/example-slug`), fetch(`${base()}/manus-routes.json`), fetch(`${base()}/api/content`)
      ]);
      for (const response of [home, adminPage, library, content, routes, result]) assert.equal(response.status, 200);
      const legacy = await result.json();
      assert.equal(legacy.services.length, 11);
      assert.equal(Object.hasOwn(legacy.settings, 'adminPassword'), false);
      assert.equal(Object.hasOwn(legacy.settings, 'adminUsername'), false);
      assert.equal((await routes.json()).routes.some((r) => r.path === '/content/:slug'), true);
    });
    await t.test('authentication rejects wrong credentials and unauthorized / CSRF writes', async () => {
      const bad = await fetch(`${base()}/api/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username, password: 'wrong-password' }) });
      assert.equal(bad.status, 401);
      const unauth = await api('/api/admin/cms/items'); assert.equal(unauth.response.status, 401);
      await login();
      const csrf = await api('/api/admin/cms/sections', { method: 'POST', body: JSON.stringify({ title: 'no csrf' }), headers: { cookie } });
      assert.equal(csrf.response.status, 403);
      const origin = await api('/api/admin/cms/sections', { admin: true, method: 'POST', body: JSON.stringify({ title: 'forged origin' }), headers: { Origin: 'https://attacker.invalid' } });
      assert.equal(origin.response.status, 403);
      const legacyPost = await api('/api/admin/service-entry', { admin: true, method: 'POST', body: JSON.stringify({ serviceId: 1, title: 'محتوى قديم متوافق', body: 'نص الخدمة القديم' }) });
      assert.equal(legacyPost.response.status, 200);
      const oldService = await api('/api/service?id=1');
      assert.equal(oldService.body.entries[0].title, 'محتوى قديم متوافق');
      const legacyMedia = await api('/api/admin/media', { admin: true });
      assert.equal(legacyMedia.response.status, 200);
      assert.ok(legacyMedia.body.some((image) => image.url === '/assets/alula-hero.jpg'));
    });

    let root; let deepest; let course; let article; let asset;
    await t.test('creates a six-level tree and rejects cycles and unsafe deletion', async () => {
      root = await createSection('تكنولوجيا تصنيع الأغذية');
      let parent = root;
      for (let i = 1; i <= 5; i++) parent = await createSection(`مستوى ${i}`, parent.id);
      deepest = parent;
      const treeResult = await api('/api/admin/cms/sections', { admin: true });
      let node = treeResult.body[0]; let depth = 1;
      while (node.children?.length) { node = node.children[0]; depth++; }
      assert.equal(depth, 6);
      const cycle = await api(`/api/admin/cms/sections/${root.id}`, { admin: true, method: 'PATCH', body: JSON.stringify({ parentId: deepest.id }) });
      assert.equal(cycle.response.status, 409);
      const deletion = await api(`/api/admin/cms/sections/${root.id}`, { admin: true, method: 'DELETE' });
      assert.equal(deletion.response.status, 409);
    });
    await t.test('creates course, lessons and article; rich HTML is sanitized and public search works', async () => {
      course = await createItem({ type: 'course', sectionId: deepest.id, title: 'تكنولوجيا الألبان', summary: 'مقدمة دورة الحليب', status: 'published', typeData: { objectives: ['فهم العملية'], targetAudience: 'مهندسو الأغذية', level: 'مبتدئ', duration: '5 ساعات' }, bodyHtml: '<h2>مقدمة الدورة</h2><p>معرفة علمية آمنة</p>' });
      const lesson = await createItem({ type: 'lesson', sectionId: deepest.id, title: 'المواد الخام', status: 'published', typeData: { courseId: course.id, sortOrder: 1 }, bodyHtml: '<h2>الحليب الخام</h2><p>شرح تقني.</p>' });
      const coursePublic = await api(`/api/public/cms/items/${course.slug}`);
      assert.equal(coursePublic.response.status, 200);
      assert.equal(coursePublic.body.lessons[0].id, lesson.id);
      article = await createItem({ type: 'article', sectionId: deepest.id, title: 'سلامة الأغذية', summary: 'مقال علمي', status: 'published', bodyHtml: '<h2>تقييم المخاطر</h2><p>البحث يشمل نظام جودة فعال.</p><script>alert(1)</script><img src="/uploads/x.jpg" onerror="alert(1)">' });
      const publicArticle = await api(`/api/public/cms/items/${article.slug}`);
      assert.doesNotMatch(publicArticle.body.body_html, /<script|onerror/i);
      const search = await api('/api/public/cms/items?q=جودة');
      assert.equal(search.body.some((item) => item.id === article.id), true);
      const draft = await createItem({ type: 'article', title: 'مسودة داخلية', status: 'draft', bodyHtml: '<p>سري</p>' });
      const draftPublic = await api(`/api/public/cms/items/${draft.slug}`);
      assert.equal(draftPublic.response.status, 404);
    });
    await t.test('recipe percentages are calculated and project/article fields are retained', async () => {
      const recipe = await createItem({ type: 'formulation', sectionId: root.id, title: 'تركيبة مشروب', status: 'published', typeData: { ingredients: [{ name: 'ماء', quantity: '80 kg', percentage: 80 }, { name: 'سكر', quantity: '20 kg', percentage: 20 }], process: 'اخلط المكونات' }, bodyHtml: '<p>وصفة تجريبية</p>' });
      assert.equal(recipe.typeData.percentageTotal, 100);
      const project = await createItem({ type: 'project', title: 'تحسين خط تعبئة', status: 'published', typeData: { problem: 'توقفات', engineeringSolution: 'تعديل تدفق', stages: ['تحليل', 'تجربة'], results: 'انخفاض التوقف', performedAt: '2026-01-01' }, bodyHtml: '<p>تفاصيل المشروع</p>' });
      assert.equal(project.typeData.stages.length, 2);
      const publicTree = await api('/api/public/cms/sections');
      assert.equal(publicTree.body[0].title, root.title);
    });
    await t.test('PDF upload is verified, stored, protected from deletion while referenced, and served', async () => {
      const pdf = Buffer.from('%PDF-1.7\n1 0 obj <<>> endobj\n%%EOF', 'ascii').toString('base64');
      const uploaded = await api('/api/admin/cms/media', { admin: true, method: 'POST', body: JSON.stringify({ name: 'reference.pdf', fileData: `data:application/pdf;base64,${pdf}` }) });
      assert.equal(uploaded.response.status, 201, JSON.stringify(uploaded.body));
      asset = uploaded.body.asset;
      const bad = await api('/api/admin/cms/media', { admin: true, method: 'POST', body: JSON.stringify({ name: 'fake.pdf', fileData: `data:application/pdf;base64,${Buffer.from('not a pdf').toString('base64')}` }) });
      assert.equal(bad.response.status, 400);
      const withAttachment = await createItem({ type: 'article', title: 'مرجع PDF', status: 'published', bodyHtml: `<p><a href="${asset.url}">فتح PDF</a></p>` });
      const blocked = await api(`/api/admin/cms/media/${asset.id}`, { admin: true, method: 'DELETE' });
      assert.equal(blocked.response.status, 409);
      const publicFile = await fetch(`${base()}${asset.url}`); assert.equal(publicFile.status, 200); assert.match(publicFile.headers.get('content-type'), /application\/pdf/);
      assert.ok(withAttachment.id);
    });

    const oldCookie = cookie;
    await stopServer();
    await startServer();
    await t.test('database, uploaded files and old site content persist across process restart; sessions expire', async () => {
      const legacy = await (await fetch(`${base()}/api/content`)).json(); assert.equal(legacy.services.length, 11);
      const items = await api('/api/admin/cms/items', { headers: { cookie: oldCookie, 'X-MALT-Admin': '1' } });
      assert.equal(items.response.status, 401);
      await login();
      const saved = await api(`/api/admin/cms/items/${article.id}`, { admin: true });
      assert.equal(saved.response.status, 200);
      assert.equal(saved.body.title, article.title);
      const file = await fetch(`${base()}${asset.url}`); assert.equal(file.status, 200);
      const routeFile = await fetch(`${base()}/manus-routes.json`); assert.equal(routeFile.status, 200);
    });
  } finally {
    await stopServer();
    await rm(temp, { recursive: true, force: true });
  }
});
