const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const sanitizeHtml = require('sanitize-html');
const { db } = require('./db');

const ROOT = __dirname;
const UPLOADS = path.resolve(process.env.MALT_UPLOAD_DIR || path.join(ROOT, 'uploads'));
const TYPES = new Set(['article', 'course', 'lesson', 'formulation', 'project', 'service']);
const STATUS = new Set(['draft', 'published', 'private']);
const FILES = new Map([
  ['image/jpeg', { ext: 'jpg', kind: 'image' }], ['image/png', { ext: 'png', kind: 'image' }],
  ['image/webp', { ext: 'webp', kind: 'image' }], ['application/pdf', { ext: 'pdf', kind: 'document' }],
  ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', { ext: 'docx', kind: 'document' }],
  ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', { ext: 'xlsx', kind: 'document' }],
  ['application/vnd.openxmlformats-officedocument.presentationml.presentation', { ext: 'pptx', kind: 'document' }],
  ['video/mp4', { ext: 'mp4', kind: 'video' }], ['video/webm', { ext: 'webm', kind: 'video' }]
]);
const maxFileMB = Math.max(1, Math.min(100, Number(process.env.CMS_MAX_FILE_MB) || 80));

function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(JSON.stringify(body));
  return true;
}
function readBody(req, limit = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const declared = Number(req.headers['content-length'] || 0);
    if (declared > limit) { req.resume(); reject(Object.assign(new Error('حجم الطلب أكبر من الحد المسموح.'), { status: 413 })); return; }
    let size = 0; const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) { req.resume(); reject(Object.assign(new Error('حجم الطلب أكبر من الحد المسموح.'), { status: 413 })); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(size ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch { reject(Object.assign(new Error('تعذرت قراءة بيانات الطلب.'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
const text = (value, max = 2000) => String(value ?? '').trim().slice(0, max);
const now = () => new Date().toISOString();
function slugBase(value) {
  const slug = text(value, 180).normalize('NFKC').toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '').slice(0, 160);
  return slug || crypto.randomUUID();
}
function uniqueSlug(table, value, existingId = '') {
  let slug = slugBase(value); let n = 1;
  while (db.prepare(`SELECT id FROM ${table} WHERE slug = ?`).get(slug)?.id !== undefined) {
    const row = db.prepare(`SELECT id FROM ${table} WHERE slug = ?`).get(slug);
    if (row && row.id === existingId) break;
    slug = `${slugBase(value)}-${++n}`;
  }
  return slug;
}
const cleanBody = (html) => sanitizeHtml(String(html || '').slice(0, 1_000_000), {
  allowedTags: ['address','article','b','blockquote','br','caption','code','dd','del','div','dl','dt','em','figcaption','figure','h1','h2','h3','h4','hr','i','img','li','ol','p','pre','s','source','span','strong','sub','sup','table','tbody','td','tfoot','th','thead','tr','u','ul','a','video'],
  allowedAttributes: {
    a: ['href','target','rel','title'], img: ['src','alt','title','width','height','loading'],
    video: ['controls','preload','poster','width','height'], source: ['src','type'],
    th: ['colspan','rowspan','scope'], td: ['colspan','rowspan'],
    '*': ['dir','lang']
  },
  allowedSchemes: ['http','https','mailto','tel'], allowedSchemesByTag: { img: ['http','https'], video: ['http','https'], source: ['http','https'] },
  allowedSchemesAppliedToAttributes: ['href','src'], allowProtocolRelative: false, enforceHtmlBoundary: true,
  transformTags: { a: sanitizeHtml.simpleTransform('a', { rel: 'noopener noreferrer', target: '_blank' }, true) }
});
function parseTypeData(value) {
  if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  if (typeof value === 'string') { try { const parsed = JSON.parse(value); return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {}; } catch { return {}; } }
  return {};
}
function itemFromRow(row) {
  if (!row) return null;
  return { ...row, typeData: JSON.parse(row.type_data || '{}'), type_data: undefined };
}
function sectionTree(publicOnly = false) {
  const rows = db.prepare(`SELECT * FROM cms_sections ${publicOnly ? "WHERE status = 'published'" : ''} ORDER BY sort_order, title`).all();
  const byParent = new Map();
  for (const row of rows) {
    const parent = row.parent_id || '';
    if (!byParent.has(parent)) byParent.set(parent, []);
    byParent.get(parent).push({ id: row.id, parentId: row.parent_id, title: row.title, slug: row.slug, description: row.description, status: row.status, sortOrder: row.sort_order, createdAt: row.created_at, updatedAt: row.updated_at });
  }
  function build(parentId, seen = new Set(), depth = 0) {
    if (depth > 1000) return [];
    return (byParent.get(parentId || '') || []).map((node) => {
      if (seen.has(node.id)) return { ...node, children: [], integrityError: true };
      const next = new Set(seen); next.add(node.id);
      return { ...node, children: build(node.id, next, depth + 1) };
    });
  }
  return build(null);
}
function publishedSectionIds() {
  const ids = new Set();
  const visit = (nodes) => { for (const node of nodes) { ids.add(node.id); visit(node.children || []); } };
  visit(sectionTree(true));
  return ids;
}
function sectionExists(id) { return !id || Boolean(db.prepare('SELECT id FROM cms_sections WHERE id = ?').get(id)); }
function wouldCycle(id, parentId) {
  let parent = parentId; const visited = new Set();
  while (parent) {
    if (parent === id || visited.has(parent)) return true;
    visited.add(parent);
    parent = db.prepare('SELECT parent_id FROM cms_sections WHERE id = ?').get(parent)?.parent_id || null;
  }
  return false;
}
function sectionDescendants(id) {
  const all = db.prepare('SELECT id, parent_id FROM cms_sections').all();
  const result = new Set([id]); let changed = true;
  while (changed) {
    changed = false;
    for (const row of all) if (row.parent_id && result.has(row.parent_id) && !result.has(row.id)) { result.add(row.id); changed = true; }
  }
  return result;
}
function allItems(admin = false) {
  const rows = db.prepare(`SELECT * FROM cms_items ${admin ? '' : "WHERE status = 'published'"} ORDER BY COALESCE(published_at, created_at) DESC, sort_order, title`).all();
  const allowedSections = admin ? null : publishedSectionIds();
  return rows.map((row) => itemFromRow(row)).filter((item) => admin || !item.section_id || allowedSections.has(item.section_id));
}
function publicItem(row) {
  if (!row) return null;
  const item = itemFromRow(row);
  const visibleSections = publishedSectionIds();
  const lessons = item.type === 'course' ? db.prepare("SELECT * FROM cms_items WHERE course_id = ? AND type = 'lesson' AND status = 'published' ORDER BY sort_order, title").all(item.id).map(itemFromRow).filter((lesson) => !lesson.section_id || visibleSections.has(lesson.section_id)) : undefined;
  return { ...item, ...(lessons ? { lessons } : {}) };
}
function stripHtml(value) { return String(value || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;|&#160;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' '); }
function notFound(res) { return json(res, 404, { message: 'المسار غير موجود.' }); }

async function publicApi(req, res, url) {
  if (url.pathname === '/api/public/cms/sections' && req.method === 'GET') return json(res, 200, sectionTree(true));
  if (url.pathname === '/api/public/cms/items' && req.method === 'GET') {
    const typeFilter = url.searchParams.get('type');
    const sectionFilter = url.searchParams.get('sectionId');
    const query = text(url.searchParams.get('q'), 150).toLocaleLowerCase();
    let list = allItems(false);
    if (typeFilter && TYPES.has(typeFilter)) list = list.filter((item) => item.type === typeFilter);
    if (sectionFilter) { const ids = sectionDescendants(sectionFilter); list = list.filter((item) => ids.has(item.section_id)); }
    if (query) list = list.filter((item) => `${item.title} ${item.summary} ${stripHtml(item.body_html)} ${JSON.stringify(item.typeData)}`.toLocaleLowerCase().includes(query));
    const limit = Math.max(1, Math.min(100, Number(url.searchParams.get('limit')) || 100));
    return json(res, 200, list.slice(0, limit));
  }
  const itemMatch = url.pathname.match(/^\/api\/public\/cms\/items\/([^/]+)$/);
  if (itemMatch && req.method === 'GET') {
    const slug = decodeURIComponent(itemMatch[1]);
    const row = db.prepare("SELECT * FROM cms_items WHERE (slug = ? OR id = ?) AND status = 'published'").get(slug, slug);
    return row ? json(res, 200, publicItem(row)) : json(res, 404, { message: 'هذا المحتوى غير متاح.' });
  }
  return false;
}
function sectionPayload(body, id = '') {
  const title = text(body.title, 180); const parentId = body.parentId ? text(body.parentId, 80) : null;
  if (!title) throw Object.assign(new Error('اسم القسم مطلوب.'), { status: 400 });
  if (!sectionExists(parentId)) throw Object.assign(new Error('القسم الأب غير موجود.'), { status: 400 });
  if (id && wouldCycle(id, parentId)) throw Object.assign(new Error('لا يمكن نقل القسم إلى نفسه أو إلى أحد أحفاده.'), { status: 409 });
  const status = body.status === 'draft' ? 'draft' : 'published';
  return { title, parentId, slug: uniqueSlug('cms_sections', body.slug || title, id), description: text(body.description, 2000), status, sortOrder: Math.max(0, Math.min(1_000_000, Number(body.sortOrder) || 0)) };
}
function normalizeItemBody(body, existing = null) {
  const type = TYPES.has(body.type) ? body.type : existing?.type;
  if (!type) throw Object.assign(new Error('نوع المحتوى غير صالح.'), { status: 400 });
  const title = text(body.title ?? existing?.title, 240);
  if (!title) throw Object.assign(new Error('عنوان المحتوى مطلوب.'), { status: 400 });
  const sectionId = body.sectionId === undefined ? (existing?.section_id || null) : (body.sectionId ? text(body.sectionId, 80) : null);
  if (!sectionExists(sectionId)) throw Object.assign(new Error('القسم المحدد غير موجود.'), { status: 400 });
  const status = STATUS.has(body.status) ? body.status : (existing?.status || 'draft');
  const typeData = parseTypeData(body.typeData === undefined ? existing?.type_data : body.typeData);
  const courseId = body.courseId === undefined ? (type === 'lesson' ? (typeData.courseId || existing?.course_id || null) : (existing?.course_id || null)) : (body.courseId ? text(body.courseId, 80) : null);
  if (type === 'lesson') {
    const course = courseId && db.prepare("SELECT id FROM cms_items WHERE id = ? AND type = 'course'").get(courseId);
    if (!course) throw Object.assign(new Error('يجب ربط الدرس بدورة موجودة.'), { status: 400 });
  }
  if (type === 'formulation') {
    const ingredients = Array.isArray(typeData.ingredients) ? typeData.ingredients : [];
    if (ingredients.some((row) => !text(row.name, 160) || (row.percentage !== '' && row.percentage != null && (!Number.isFinite(Number(row.percentage)) || Number(row.percentage) < 0 || Number(row.percentage) > 100)))) {
      throw Object.assign(new Error('تحقق من أسماء المكونات والنسب (من 0 إلى 100).'), { status: 400 });
    }
    typeData.ingredients = ingredients.map((row) => ({ name: text(row.name, 160), quantity: text(row.quantity, 80), percentage: row.percentage === '' || row.percentage == null ? null : Number(row.percentage) }));
    typeData.percentageTotal = Number(typeData.ingredients.reduce((sum, row) => sum + (Number(row.percentage) || 0), 0).toFixed(4));
  }
  const existingBody = existing?.body_html || '';
  const bodyHtml = body.bodyHtml === undefined ? existingBody : cleanBody(body.bodyHtml);
  const publishedAt = status === 'published' ? (existing?.published_at || now()) : null;
  return {
    type, title, sectionId, courseId, slug: uniqueSlug('cms_items', body.slug || title, existing?.id || ''),
    summary: text(body.summary ?? existing?.summary, 1200), bodyHtml, status, typeData,
    sortOrder: Math.max(0, Math.min(1_000_000, Number(body.sortOrder ?? existing?.sort_order) || 0)), publishedAt
  };
}
function itemJson(row) { return itemFromRow(row); }
function validateUpload(dataUrl, originalName) {
  const match = String(dataUrl || '').match(/^data:([^;,]+);base64,([A-Za-z0-9+/=\r\n]+)$/);
  if (!match) throw Object.assign(new Error('تعذر قراءة الملف المرفوع.'), { status: 400 });
  const mime = match[1].toLowerCase(); const spec = FILES.get(mime);
  if (!spec) throw Object.assign(new Error('الصيغ المقبولة: الصور JPG/PNG/WEBP، الفيديو MP4/WEBM، والمستندات PDF/DOCX/XLSX/PPTX.'), { status: 400 });
  const bytes = Buffer.from(match[2].replace(/[\r\n]/g, ''), 'base64');
  if (!bytes.length || bytes.length > maxFileMB * 1024 * 1024) throw Object.assign(new Error(`حجم الملف يتجاوز الحد (${maxFileMB} MB).`), { status: 413 });
  let valid = false;
  if (mime === 'image/jpeg') valid = bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  else if (mime === 'image/png') valid = bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  else if (mime === 'image/webp') valid = bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
  else if (mime === 'application/pdf') valid = bytes.subarray(0, 5).toString('ascii') === '%PDF-';
  else if (mime.startsWith('application/vnd.openxmlformats-officedocument')) valid = bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && bytes[2] === 0x03 && bytes[3] === 0x04;
  else if (mime === 'video/mp4') valid = bytes.length > 12 && bytes.toString('ascii', 4, 8) === 'ftyp';
  else if (mime === 'video/webm') valid = bytes.length > 4 && bytes.subarray(0, 4).equals(Buffer.from([0x1a,0x45,0xdf,0xa3]));
  if (!valid) throw Object.assign(new Error('نوع الملف لا يطابق توقيعه أو أن الملف تالف.'), { status: 400 });
  return { bytes, mime, ...spec, name: path.basename(text(originalName, 180)).replace(/[\u0000-\u001f]/g, '') };
}
function allMedia() { return db.prepare('SELECT id, original_name AS name, url, mime, kind, size_bytes AS size, alt_text AS alt, description, created_at AS date FROM cms_media ORDER BY created_at DESC').all(); }

async function adminApi(req, res, url) {
  if (!url.pathname.startsWith('/api/admin/cms/')) return false;
  try {
    if (url.pathname === '/api/admin/cms/sections' && req.method === 'GET') return json(res, 200, sectionTree(false));
    if (url.pathname === '/api/admin/cms/sections' && req.method === 'POST') {
      const body = await readBody(req, 256 * 1024); const item = sectionPayload(body); const timestamp = now(); const id = crypto.randomUUID();
      db.prepare('INSERT INTO cms_sections(id,parent_id,title,slug,description,status,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)').run(id,item.parentId,item.title,item.slug,item.description,item.status,item.sortOrder,timestamp,timestamp);
      return json(res, 201, { ok: true, section: { id, ...item }, message: 'تم إنشاء القسم.' });
    }
    const sectionMatch = url.pathname.match(/^\/api\/admin\/cms\/sections\/([^/]+)$/);
    if (sectionMatch && req.method === 'PATCH') {
      const id = decodeURIComponent(sectionMatch[1]); const existing = db.prepare('SELECT * FROM cms_sections WHERE id = ?').get(id);
      if (!existing) return json(res, 404, { message: 'القسم غير موجود.' });
      const body = await readBody(req, 256 * 1024); const item = sectionPayload({ ...existing, ...body, parentId: body.parentId === undefined ? existing.parent_id : body.parentId, status: body.status || existing.status }, id);
      db.prepare('UPDATE cms_sections SET parent_id=?,title=?,slug=?,description=?,status=?,sort_order=?,updated_at=? WHERE id=?').run(item.parentId,item.title,item.slug,item.description,item.status,item.sortOrder,now(),id);
      return json(res, 200, { ok: true, section: { id, ...item } });
    }
    if (sectionMatch && req.method === 'DELETE') {
      const id = decodeURIComponent(sectionMatch[1]);
      const hasChildren = db.prepare('SELECT 1 FROM cms_sections WHERE parent_id = ? LIMIT 1').get(id);
      const hasContent = db.prepare('SELECT 1 FROM cms_items WHERE section_id = ? LIMIT 1').get(id);
      if (hasChildren || hasContent) return json(res, 409, { message: 'لا يمكن حذف قسم يحتوي أقسامًا فرعية أو محتوى. انقلها أو احذفها أولًا.' });
      const result = db.prepare('DELETE FROM cms_sections WHERE id = ?').run(id);
      return result.changes ? json(res, 200, { ok: true }) : json(res, 404, { message: 'القسم غير موجود.' });
    }
    if (url.pathname === '/api/admin/cms/items' && req.method === 'GET') return json(res, 200, allItems(true));
    if (url.pathname === '/api/admin/cms/items' && req.method === 'POST') {
      const body = await readBody(req, 2 * 1024 * 1024); const item = normalizeItemBody(body); const id = crypto.randomUUID(); const timestamp = now();
      db.prepare('INSERT INTO cms_items(id,section_id,type,course_id,title,slug,summary,body_html,status,type_data,sort_order,published_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,item.sectionId,item.type,item.courseId,item.title,item.slug,item.summary,item.bodyHtml,item.status,JSON.stringify(item.typeData),item.sortOrder,item.publishedAt,timestamp,timestamp);
      return json(res, 201, { ok: true, item: { id, ...item, created_at: timestamp, updated_at: timestamp }, message: 'تم حفظ المحتوى.' });
    }
    const itemMatch = url.pathname.match(/^\/api\/admin\/cms\/items\/([^/]+)$/);
    if (itemMatch && req.method === 'GET') {
      const id = decodeURIComponent(itemMatch[1]);
      const row = db.prepare('SELECT * FROM cms_items WHERE id = ?').get(id);
      return row ? json(res, 200, itemJson(row)) : json(res, 404, { message: 'المحتوى غير موجود.' });
    }
    if (itemMatch && req.method === 'PATCH') {
      const id = decodeURIComponent(itemMatch[1]); const existing = db.prepare('SELECT * FROM cms_items WHERE id = ?').get(id);
      if (!existing) return json(res, 404, { message: 'المحتوى غير موجود.' });
      const body = await readBody(req, 2 * 1024 * 1024); const item = normalizeItemBody(body, existing);
      db.prepare('UPDATE cms_items SET section_id=?,type=?,course_id=?,title=?,slug=?,summary=?,body_html=?,status=?,type_data=?,sort_order=?,published_at=?,updated_at=? WHERE id=?').run(item.sectionId,item.type,item.courseId,item.title,item.slug,item.summary,item.bodyHtml,item.status,JSON.stringify(item.typeData),item.sortOrder,item.publishedAt,now(),id);
      return json(res, 200, { ok: true, item: { id, ...item }, message: 'تم تحديث المحتوى.' });
    }
    if (itemMatch && req.method === 'DELETE') {
      const id = decodeURIComponent(itemMatch[1]);
      if (db.prepare("SELECT 1 FROM cms_items WHERE course_id = ? AND type = 'lesson' LIMIT 1").get(id)) return json(res, 409, { message: 'احذف دروس الدورة أو انقلها قبل حذف الدورة.' });
      const result = db.prepare('DELETE FROM cms_items WHERE id = ?').run(id);
      return result.changes ? json(res, 200, { ok: true }) : json(res, 404, { message: 'المحتوى غير موجود.' });
    }
    if (url.pathname === '/api/admin/cms/media' && req.method === 'GET') return json(res, 200, allMedia());
    if (url.pathname === '/api/admin/cms/media' && req.method === 'POST') {
      const body = await readBody(req, Math.ceil(maxFileMB * 1.45 * 1024 * 1024) + 256 * 1024); const file = validateUpload(body.fileData, body.name);
      const filename = `${Date.now()}-${crypto.randomBytes(16).toString('hex')}.${file.ext}`; const id = crypto.randomUUID();
      fs.mkdirSync(UPLOADS, { recursive: true });
      const target = path.join(UPLOADS, filename);
      fs.writeFileSync(target, file.bytes, { flag: 'wx', mode: 0o640 });
      const asset = { id, name: file.name || filename, url: `/uploads/${filename}`, mime: file.mime, kind: file.kind, size: file.bytes.length, alt: text(body.alt, 300), description: text(body.description, 1000), date: now() };
      try {
        db.prepare('INSERT INTO cms_media(id,original_name,storage_name,url,mime,kind,size_bytes,alt_text,description,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(asset.id,asset.name,filename,asset.url,asset.mime,asset.kind,asset.size,asset.alt,asset.description,asset.date);
      } catch (error) { fs.unlinkSync(target); throw error; }
      return json(res, 201, { ok: true, asset, message: 'تم حفظ الملف في مكتبة الوسائط.' });
    }
    const mediaMatch = url.pathname.match(/^\/api\/admin\/cms\/media\/([^/]+)$/);
    if (mediaMatch && req.method === 'PATCH') {
      const id = decodeURIComponent(mediaMatch[1]); const body = await readBody(req, 128 * 1024);
      const result = db.prepare('UPDATE cms_media SET alt_text=?,description=? WHERE id=?').run(text(body.alt,300),text(body.description,1000),id);
      return result.changes ? json(res,200,{ok:true}) : json(res,404,{message:'الملف غير موجود.'});
    }
    if (mediaMatch && req.method === 'DELETE') {
      const id = decodeURIComponent(mediaMatch[1]); const asset = db.prepare('SELECT * FROM cms_media WHERE id=?').get(id);
      if (!asset) return json(res,404,{message:'الملف غير موجود.'});
      const used = db.prepare('SELECT id,title FROM cms_items WHERE body_html LIKE ? OR type_data LIKE ? LIMIT 1').get(`%${asset.url}%`,`%${asset.url}%`);
      if (used) return json(res,409,{message:`الملف مستخدم في المحتوى «${used.title}». أزل الارتباط أولًا.`});
      db.prepare('DELETE FROM cms_media WHERE id=?').run(id); const target = path.join(UPLOADS, path.basename(asset.storage_name)); if (fs.existsSync(target)) fs.unlinkSync(target);
      return json(res,200,{ok:true});
    }
    return notFound(res);
  } catch (error) {
    if (error.status) return json(res, error.status, { message: error.message });
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') return json(res, 409, { message: 'يوجد قسم أو محتوى بهذا الرابط بالفعل.' });
    console.error('CMS API error:', error);
    return json(res, 500, { message: 'حدث خطأ أثناء معالجة طلب إدارة المحتوى.' });
  }
}

module.exports = { publicApi, adminApi, cleanBody, maxFileMB, fileTypes: FILES };
